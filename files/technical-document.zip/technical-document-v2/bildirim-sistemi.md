# Bildirim Sistemi

DentiRemind uygulamasının en önemli bileşenlerinden biri olan bildirim sistemi, kullanıcıların tedavi ve kontrol randevularını zamanında hatırlamalarını sağlar. Bu bölümde, bildirim sisteminin mimarisi, çalışma prensibi ve entegrasyon detayları ele alınmaktadır.

## Genel Mimari

DentiRemind'ın bildirim sistemi, aşağıdaki temel bileşenlerden oluşmaktadır:

1. **Bildirim Servisi**: Backend'de çalışan ve bildirimlerin zamanlamasını, oluşturulmasını ve gönderilmesini yöneten servis
2. **Push Notification Sağlayıcıları**: Firebase Cloud Messaging (FCM) ve Apple Push Notification Service (APNs)
3. **Cihaz Token Yönetimi**: Kullanıcıların cihaz tokenlarının veritabanında saklanması ve yönetilmesi
4. **Bildirim İçerik Şablonları**: Farklı bildirim türleri için önceden tanımlanmış şablonlar
5. **Bildirim Tercih Sistemi**: Kullanıcıların bildirim tercihlerini yapılandırabilmelerini sağlayan altyapı

![Bildirim Sistemi Mimarisi](https://via.placeholder.com/800x400?text=Bildirim+Sistemi+Mimarisi)

## Bildirim Servisi

Bildirim servisi, backend'de çalışan ve aşağıdaki temel işlevleri yerine getiren bir mikroservistir:

### Zamanlanmış İş Yapısı

Bildirimler, Agenda.js kütüphanesi kullanılarak zamanlanır. Her hatırlatıcı için şu iş tipi oluşturulur:

```javascript
// Zamanlanmış bildirim işi örneği
{
  type: 'sendNotification',
  data: {
    reminderId: '60a1e2c05e4c2a0015d6a1e1',
    userId: '60a1e2c05e4c2a0015d6a1a1',
    title: 'Diş Kontrolü Hatırlatıcısı',
    message: 'Yarın saat 14:30\'da Dr. Mehmet Kaya ile randevunuz var',
    notificationType: 'appointment',
    deepLink: 'dentiremind://appointments/60a1e2c05e4c2a0015d6a1f1'
  },
  priority: 'high',
  nextRunAt: new Date('2023-06-09T08:30:00Z')
}
```

### Bildirim İşleme Mantığı

1. **Zamanlanmış İşlerin Kontrolü**: Her dakika, zamanı gelen işler kontrol edilir
2. **Kullanıcı Tercihlerinin Kontrolü**: Kullanıcının bildirim tercihleri kontrol edilir
3. **Bildirim Şablonunun Seçilmesi**: Bildirim türüne göre uygun şablon seçilir
4. **Cihaz Tokenlarının Alınması**: Kullanıcının aktif cihaz tokenları veritabanından alınır
5. **Bildirim Gönderimi**: İlgili push notification servislerine bildirim gönderilir
6. **Bildirim Kaydı**: Gönderilen bildirim, veritabanına kaydedilir
7. **Tekrarlayan Hatırlatıcılar**: Tekrarlayan hatırlatıcılar için bir sonraki bildirim zamanlanır

## Push Notification Sağlayıcıları

### Firebase Cloud Messaging (FCM)

Android cihazlar için FCM kullanılmaktadır:

```javascript
// FCM bildirim gönderimi örneği
async function sendFCMNotification(deviceToken, notification) {
  try {
    const message = {
      token: deviceToken,
      notification: {
        title: notification.title,
        body: notification.message
      },
      data: {
        type: notification.notificationType,
        reminderId: notification.reminderId,
        deepLink: notification.deepLink
      },
      android: {
        priority: 'high',
        notification: {
          sound: 'default',
          channelId: 'reminders'
        }
      }
    };
    
    const response = await admin.messaging().send(message);
    return { success: true, messageId: response };
  } catch (error) {
    logger.error('FCM gönderim hatası:', error);
    return { success: false, error };
  }
}
```

### Apple Push Notification Service (APNs)

iOS cihazlar için APNs kullanılmaktadır:

```javascript
// APNs bildirim gönderimi örneği
async function sendAPNsNotification(deviceToken, notification) {
  try {
    const payload = {
      aps: {
        alert: {
          title: notification.title,
          body: notification.message
        },
        sound: 'default',
        badge: 1
      },
      type: notification.notificationType,
      reminderId: notification.reminderId,
      deepLink: notification.deepLink
    };
    
    const response = await apnProvider.send(payload, deviceToken);
    return { success: true, messageId: response.sent[0] };
  } catch (error) {
    logger.error('APNs gönderim hatası:', error);
    return { success: false, error };
  }
}
```

## Cihaz Token Yönetimi

Kullanıcının her cihazı için benzersiz bir token oluşturulur ve bu tokenlar veritabanında saklanır:

### Token Ekleme

```javascript
// Token ekleme/güncelleme API endpoint'i
router.post('/users/device-token', authenticate, async (req, res) => {
  try {
    const { deviceToken, deviceType, deviceName } = req.body;
    const userId = req.user.id;
    
    // Token zaten var mı kontrol et
    const existingToken = await User.findOne({
      _id: userId,
      'deviceTokens.token': deviceToken
    });
    
    if (!existingToken) {
      // Yeni token ekle
      await User.updateOne(
        { _id: userId },
        { 
          $push: { 
            deviceTokens: {
              token: deviceToken,
              deviceType,
              deviceName,
              lastActive: new Date()
            }
          }
        }
      );
    } else {
      // Token'in son aktif zamanını güncelle
      await User.updateOne(
        { _id: userId, 'deviceTokens.token': deviceToken },
        { $set: { 'deviceTokens.$.lastActive': new Date() } }
      );
    }
    
    return res.status(200).json({ success: true });
  } catch (error) {
    return res.status(500).json({ 
      success: false, 
      error: 'Device token eklenemedi' 
    });
  }
});
```

### Token Silme

```javascript
// Token silme API endpoint'i
router.delete('/users/device-token/:token', authenticate, async (req, res) => {
  try {
    const { token } = req.params;
    const userId = req.user.id;
    
    await User.updateOne(
      { _id: userId },
      { $pull: { deviceTokens: { token } } }
    );
    
    return res.status(200).json({ success: true });
  } catch (error) {
    return res.status(500).json({ 
      success: false, 
      error: 'Device token silinemedi' 
    });
  }
});
```

## Bildirim İçerik Şablonları

Farklı bildirim türleri için özel şablonlar kullanılmaktadır:

### Şablon Örnekleri

```javascript
const notificationTemplates = {
  'appointment_reminder': {
    title: 'Randevu Hatırlatıcısı',
    message: '{dentistName} ile {date} tarihinde saat {time} randevunuz var'
  },
  'medication_reminder': {
    title: 'İlaç Hatırlatıcısı',
    message: '{medicationName} ilacınızı almanın zamanı geldi'
  },
  'checkup_reminder': {
    title: 'Kontrol Hatırlatıcısı',
    message: '6 aylık rutin diş kontrolünüz için randevu zamanı geldi'
  },
  'treatment_completion': {
    title: 'Tedavi Tamamlandı',
    message: '{treatmentName} tedaviniz bugün tamamlandı. Nasıl geçtiğini değerlendirebilirsiniz'
  }
};

function formatNotificationMessage(template, data) {
  let { title, message } = notificationTemplates[template];
  
  // Şablon değerlerini değiştir
  Object.keys(data).forEach(key => {
    const regex = new RegExp(`{${key}}`, 'g');
    title = title.replace(regex, data[key]);
    message = message.replace(regex, data[key]);
  });
  
  return { title, message };
}
```

## Bildirim Tercih Sistemi

Kullanıcılar bildirim tercihlerini yapılandırabilir:

### Tercih Ayarları

- **Bildirim Kanalları**: Push, e-posta, SMS
- **Bildirim Türleri**: Randevu, ilaç, kontrol, tedavi
- **Bildirim Zamanları**: Olay öncesi bildirim süresi (5 dk, 15 dk, 1 saat, 1 gün)
- **Sessiz Saatler**: Belirli saat aralıklarında bildirim gelmemesi

### Kullanıcı Tercihlerini Güncelleme

```javascript
// Bildirim tercihlerini güncelleme API endpoint'i
router.put('/users/notification-preferences', authenticate, async (req, res) => {
  try {
    const { preferences } = req.body;
    const userId = req.user.id;
    
    await User.updateOne(
      { _id: userId },
      { 
        $set: { 
          'settings.notificationPreferences': preferences 
        } 
      }
    );
    
    return res.status(200).json({ 
      success: true, 
      preferences 
    });
  } catch (error) {
    return res.status(500).json({ 
      success: false, 
      error: 'Bildirim tercihleri güncellenemedi' 
    });
  }
});
```

## Bildirim Etkileşim Takibi

Kullanıcıların bildirimlerle etkileşimleri takip edilir:

### Etkileşim Türleri

- Görüntülenme
- Tıklama
- Kapatma
- Erteleme (snooze)

### Etkileşim Kaydetme

```javascript
// Bildirim etkileşimi kaydetme API endpoint'i
router.post('/notifications/:notificationId/interaction', authenticate, async (req, res) => {
  try {
    const { notificationId } = req.params;
    const { interactionType, timestamp } = req.body;
    const userId = req.user.id;
    
    await Notification.updateOne(
      { _id: notificationId, userId },
      { 
        $push: { 
          interactions: {
            type: interactionType,
            timestamp: timestamp || new Date()
          }
        },
        $set: {
          isRead: interactionType === 'view' || interactionType === 'click'
        }
      }
    );
    
    return res.status(200).json({ success: true });
  } catch (error) {
    return res.status(500).json({ 
      success: false, 
      error: 'Bildirim etkileşimi kaydedilemedi' 
    });
  }
});
```

## Tekrarlayan Hatırlatıcılar

Tekrarlayan hatırlatıcılar için özel bir zamanlamaya mantığı uygulanır:

### Tekrarlama Mantığı

```javascript
// Bir sonraki hatırlatıcı zamanını hesaplama
function calculateNextReminderTime(reminder) {
  const { recurrence, dateTime } = reminder;
  let nextDate = new Date(dateTime);
  
  switch (recurrence.pattern) {
    case 'daily':
      nextDate.setDate(nextDate.getDate() + recurrence.interval);
      break;
    case 'weekly':
      nextDate.setDate(nextDate.getDate() + (7 * recurrence.interval));
      break;
    case 'monthly':
      nextDate.setMonth(nextDate.getMonth() + recurrence.interval);
      break;
    case 'yearly':
      nextDate.setFullYear(nextDate.getFullYear() + recurrence.interval);
      break;
    case 'custom':
      // Özel tekrarlama mantığı (belirli günler, vb.)
      nextDate = calculateCustomRecurrence(reminder);
      break;
  }
  
  // Tekrarlama sonu kontrolü
  if (recurrence.endDate && nextDate > new Date(recurrence.endDate)) {
    return null; // Tekrarlama sona erdi
  }
  
  // Tekrarlama sayısı kontrolü
  if (recurrence.timesRepeated !== undefined) {
    reminder.recurrence.currentRepeatCount = (reminder.recurrence.currentRepeatCount || 0) + 1;
    if (reminder.recurrence.currentRepeatCount >= recurrence.timesRepeated) {
      return null; // Tekrarlama sayısı tamamlandı
    }
  }
  
  return nextDate;
}
```

## Acil Bildirimler

Acil durumlarda (örn. randevu iptali) kullanıcıya hemen bildirim göndermek için özel bir mekanizma mevcuttur:

```javascript
// Acil bildirim gönderme
async function sendUrgentNotification(userId, notification) {
  try {
    // Kullanıcı bilgilerini al
    const user = await User.findById(userId).select('deviceTokens settings.notificationPreferences');
    
    if (!user) {
      throw new Error('Kullanıcı bulunamadı');
    }
    
    // Bildirimi veritabanına kaydet
    const notificationRecord = await Notification.create({
      userId,
      title: notification.title,
      message: notification.message,
      notificationType: notification.type,
      relatedItemId: notification.relatedItemId,
      relatedItemType: notification.relatedItemType,
      isRead: false,
      createdAt: new Date(),
      isUrgent: true
    });
    
    // Tüm aktif cihazlara bildirim gönder
    const activeTokens = user.deviceTokens.filter(dt => 
      new Date(dt.lastActive) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    );
    
    if (activeTokens.length === 0) {
      // E-posta ile bildirim gönder
      await sendEmailNotification(user, notification);
      return;
    }
    
    // Cihaz türüne göre ayrıştır
    const androidTokens = activeTokens
      .filter(dt => dt.deviceType === 'android')
      .map(dt => dt.token);
      
    const iosTokens = activeTokens
      .filter(dt => dt.deviceType === 'ios')
      .map(dt => dt.token);
    
    // Android bildirimleri
    if (androidTokens.length > 0) {
      await sendFCMNotification(androidTokens, {
        ...notification,
        priority: 'high',
        id: notificationRecord._id
      });
    }
    
    // iOS bildirimleri
    if (iosTokens.length > 0) {
      await Promise.all(iosTokens.map(token => 
        sendAPNsNotification(token, {
          ...notification,
          priority: 10,
          id: notificationRecord._id
        })
      ));
    }
    
    return notificationRecord;
  } catch (error) {
    logger.error('Acil bildirim gönderim hatası:', error);
    throw error;
  }
}
```

## Bildirim Gruplaması

Çok sayıda bildirim olduğunda, kullanıcı deneyimini iyileştirmek için bildirimler gruplandırılır:

```javascript
// Bildirim gruplaması
function groupNotifications(notifications) {
  const groups = {};
  
  notifications.forEach(notification => {
    const key = notification.relatedItemType;
    
    if (!groups[key]) {
      groups[key] = [];
    }
    
    groups[key].push(notification);
  });
  
  // Grupları düzenle
  Object.keys(groups).forEach(key => {
    if (groups[key].length > 3) {
      groups[key] = {
        type: key,
        count: groups[key].length,
        recentItems: groups[key].slice(0, 3)
      };
    }
  });
  
  return groups;
}
```

## Performans ve Ölçeklenebilirlik

Bildirim servisi, yüksek performans ve ölçeklenebilirlik için optimize edilmiştir:

### Optimizasyon Stratejileri

1. **Batch İşleme**: Bildirimlerin toplu olarak işlenmesi
2. **Redis Önbellek**: Sık kullanılan verilerin önbelleklenmesi
3. **İş Kuyruğu**: Yoğun bildirim gönderimlerinin kuyruklanması
4. **Otomatik Ölçeklendirme**: Yüksek yük durumlarında servis kapasitesinin otomatik artırılması

### Batch Bildirim Gönderimi

```javascript
// Toplu bildirim gönderimi
async function sendBatchNotifications() {
  try {
    // Gönderilecek bildirimleri getir
    const now = new Date();
    const pendingNotifications = await Agenda.find({
      type: 'sendNotification',
      nextRunAt: { $lte: now }
    }).limit(100);
    
    // Kullanıcılara göre grupla
    const notificationsByUser = {};
    pendingNotifications.forEach(notification => {
      const userId = notification.data.userId;
      
      if (!notificationsByUser[userId]) {
        notificationsByUser[userId] = [];
      }
      
      notificationsByUser[userId].push(notification);
    });
    
    // Her kullanıcı için bildirimleri gönder
    for (const userId in notificationsByUser) {
      await processUserNotifications(userId, notificationsByUser[userId]);
    }
  } catch (error) {
    logger.error('Toplu bildirim gönderim hatası:', error);
  }
}
```

## Entegrasyon Rehberi

### Backend Entegrasyonu

1. **Firebase Admin SDK Kurulumu**:
   ```
   npm install firebase-admin
   ```

2. **APNs Sertifika Kurulumu**:
   ```
   openssl pkcs12 -in APNsCertificate.p12 -out key.pem -nodes -nocerts
   ```

3. **Bildirim Servisinin Yapılandırılması**:
   ```javascript
   // Bildirim servisi başlatma
   const admin = require('firebase-admin');
   const serviceAccount = require('./firebase-service-account.json');
   
   admin.initializeApp({
     credential: admin.credential.cert(serviceAccount)
   });
   
   const apn = require('apn');
   const apnProvider = new apn.Provider({
     token: {
       key: './key.pem',
       keyId: 'KEY_ID',
       teamId: 'TEAM_ID'
     },
     production: process.env.NODE_ENV === 'production'
   });
   ```

### Mobil Uygulama Entegrasyonu

**Android (React Native):**

```javascript
// Firebase Cloud Messaging kurulumu
import messaging from '@react-native-firebase/messaging';

async function requestNotificationPermission() {
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

  if (enabled) {
    console.log('Bildirim izni verildi');
    
    // Token al ve sunucuya gönder
    const token = await messaging().getToken();
    if (token) {
      await sendTokenToServer(token);
    }
    
    // Token yenilendiğinde
    messaging().onTokenRefresh(async (newToken) => {
      await sendTokenToServer(newToken);
    });
  }
}

// Bildirimleri dinle
messaging().onMessage(async (remoteMessage) => {
  console.log('Ön planda bildirim alındı:', remoteMessage);
  // Bildirimi göster
  showLocalNotification(remoteMessage);
});

// Bildirime tıklanınca
messaging().onNotificationOpenedApp((remoteMessage) => {
  console.log('Bildirime tıklandı:', remoteMessage);
  // İlgili ekrana yönlendir
  handleNotificationNavigation(remoteMessage);
});

// Uygulama kapalıyken tıklanan bildirim
messaging()
  .getInitialNotification()
  .then((remoteMessage) => {
    if (remoteMessage) {
      console.log('Başlangıç bildirimi:', remoteMessage);
      // İlgili ekrana yönlendir
      handleNotificationNavigation(remoteMessage);
    }
  });
```

**iOS (React Native):**

```javascript
// APNs için izin isteme
import PushNotificationIOS from '@react-native-community/push-notification-ios';

function requestNotificationPermission() {
  PushNotificationIOS.requestPermissions({
    alert: true,
    badge: true,
    sound: true
  }).then((permissions) => {
    console.log('İzinler:', permissions);
    
    // Token al
    PushNotificationIOS.getAPNSToken().then((token) => {
      if (token) {
        // Token'ı sunucuya gönder
        sendTokenToServer(token);
      }
    });
  });
}
```

## Sorun Giderme

### Genel Sorunlar ve Çözümleri

1. **Bildirim Gelmiyor**
   - Kullanıcı bildirim izinlerini kontrol edin
   - Cihaz token'ın geçerli olduğunu doğrulayın
   - Bildirim servisinin çalıştığını doğrulayın
   - Log kayıtlarını inceleyin

2. **Bildirim Gecikiyor**
   - Zamanlanmış iş servisinin düzgün çalıştığını kontrol edin
   - Sunucu zamanı ile yerel zaman senkronizasyonunu doğrulayın
   - Kullanıcının zaman dilimi ayarını kontrol edin

3. **İstenmeyen Bildirimler**
   - Kullanıcının bildirim tercihlerini kontrol edin
   - Tekrarlama mantığını gözden geçirin
   - Silinen hatırlatıcıların bildirimlerinin iptal edildiğini doğrulayın

### Log Analizi

```javascript
// Bildirim servisi loglama
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  defaultMeta: { service: 'notification-service' },
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

// Örnek log kaydı
logger.info('Bildirim gönderildi', {
  notificationId: notification._id,
  userId: userId,
  status: 'success',
  timestamp: new Date(),
  deviceType: deviceType,
  messageId: response.messageId
});
```

[İçindekiler Sayfasına Dön](giris.md) 