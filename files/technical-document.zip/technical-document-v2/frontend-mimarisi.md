# Frontend Mimarisi

DentiRemind'ın mobil uygulaması, React Native framework'ü üzerine inşa edilmiştir ve modern mobil uygulama mimarisi prensiplerini takip etmektedir. Bu bölümde, frontend mimarisinin temel bileşenleri ve organizasyonu detaylandırılmıştır.

## Dosya Yapısı

DentiRemind mobil uygulamasının temel dosya yapısı aşağıdaki gibidir:

```
dentiremind-mobile/
├── android/                # Android native kodu
├── ios/                    # iOS native kodu
├── src/
│   ├── assets/             # Statik varlıklar (resimler, fontlar, vb.)
│   ├── components/         # Paylaşılan UI bileşenleri
│   │   ├── common/         # Genel bileşenler
│   │   ├── treatments/     # Tedavi ile ilgili bileşenler
│   │   ├── reminders/      # Hatırlatıcı ile ilgili bileşenler
│   │   └── ...
│   ├── config/             # Yapılandırma dosyaları
│   ├── constants/          # Sabitler ve enum'lar
│   ├── hooks/              # Özel React hook'ları
│   ├── navigation/         # Navigasyon yapılandırması
│   ├── screens/            # Uygulama ekranları
│   │   ├── auth/           # Kimlik doğrulama ekranları
│   │   ├── profile/        # Profil ekranları
│   │   ├── treatments/     # Tedavi ekranları
│   │   ├── reminders/      # Hatırlatıcı ekranları
│   │   └── ...
│   ├── services/           # API ve yerel servisler
│   │   ├── api/            # API çağrıları
│   │   ├── storage/        # Yerel depolama
│   │   ├── notifications/  # Bildirim servisleri
│   │   └── ...
│   ├── store/              # State yönetimi (Redux)
│   │   ├── actions/        # Redux actions
│   │   ├── reducers/       # Redux reducers
│   │   ├── types/          # Tip tanımları
│   │   ├── selectors/      # Redux selectors
│   │   └── middleware/     # Redux middleware
│   ├── styles/             # Genel stil tanımlamaları
│   ├── types/              # TypeScript tip tanımlamaları
│   ├── utils/              # Yardımcı fonksiyonlar
│   └── App.tsx             # Ana uygulama bileşeni
├── .env                    # Ortam değişkenleri
├── package.json            # Bağımlılıklar ve komutlar
└── tsconfig.json           # TypeScript yapılandırması
```

## Mimari Yaklaşım

DentiRemind uygulaması, aşağıdaki mimari prensipler ve desenler üzerine kurulmuştur:

### 1. Atomic Design Metodolojisi

Kullanıcı arayüzü bileşenleri, Atomic Design prensiplerine göre organize edilmiştir:

- **Atomlar**: Butonlar, giriş alanları, ikonlar gibi temel bileşenler
- **Moleküller**: Form grupları, kart başlıkları gibi atomlardan oluşan kompozit bileşenler
- **Organizmalar**: Tedavi kartları, hatırlatıcı listeleri gibi kompleks bileşenler
- **Şablonlar**: Ekran düzenleri ve yerleşimleri
- **Sayfalar**: Tam ekran görünümleri

### 2. Redux State Yönetimi

Uygulama durumu, Redux kullanılarak merkezi bir depoda yönetilmektedir:

- **Eylemler (Actions)**: Kullanıcı etkileşimleri ve API çağrıları için tanımlanan eylemler
- **Reducer'lar**: Durum değişikliklerini handle eden saf fonksiyonlar
- **Selectors**: Durum ağacından veri seçimi için optimize edilmiş fonksiyonlar
- **Middleware**: Redux-Thunk ile asenkron işlemlerin yönetimi

### 3. Katmanlı Mimari

Uygulama, sorumlulukları net bir şekilde ayıran katmanlı bir mimariye sahiptir:

- **Sunum Katmanı**: Ekranlar ve UI bileşenleri
- **Durum Yönetim Katmanı**: Redux store ve ilgili bileşenler
- **Servis Katmanı**: API iletişimi, veri dönüşümü, yerel depolama
- **İş Mantığı Katmanı**: Veri işleme, validasyon, hesaplamalar

## Ekran Akış Diyagramı

Aşağıdaki diyagram, uygulamanın temel ekran akışını göstermektedir:

```
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│   Splash    │──────▶    Giriş    │──────▶  Ana Sayfa  │
└─────────────┘      └─────────────┘      └──────┬──────┘
                           ▲                     │
                           │                     ▼
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│    Üyelik   │──────▶    Onay     │      │   Tedaviler │◀───┐
└─────────────┘      └─────────────┘      └──────┬──────┘    │
                                                  │          │
                                                  ▼          │
┌─────────────┐      ┌─────────────┐      ┌─────────────┐   │
│  Hatırlatıcı│◀─────┤ Hatırlatıcı │◀─────┤Tedavi Detay │───┘
│   Detay     │      │   Listesi   │      └─────────────┘
└─────────────┘      └─────────────┘
```

## Bileşen Hiyerarşisi

Aşağıda, uygulamanın temel ekranlarından biri olan Tedavi Ekranı için bileşen hiyerarşisi verilmiştir:

```
TreatmentsScreen
├── HeaderComponent
│   ├── SearchBar
│   └── FilterButton
├── TreatmentList
│   ├── TreatmentCard
│   │   ├── TreatmentHeader
│   │   │   ├── CategoryIcon
│   │   │   └── TreatmentTitle
│   │   ├── TreatmentInfo
│   │   │   ├── DateDisplay
│   │   │   ├── DentistInfo
│   │   │   └── StatusBadge
│   │   └── TreatmentActions
│   │       ├── EditButton
│   │       ├── DeleteButton
│   │       └── ReminderButton
│   └── EmptyStateComponent
└── AddTreatmentFAB
```

## State Yönetimi

DentiRemind uygulamasında, React ve Redux kombinasyonu kullanılarak kapsamlı bir durum yönetimi stratejisi uygulanmaktadır:

### Global State

Redux store'da yönetilen global durum aşağıdaki bölümlere ayrılmıştır:

```javascript
{
  auth: {
    user: { /* kullanıcı bilgileri */ },
    token: "jwt_token",
    isAuthenticated: true,
    loading: false,
    error: null
  },
  treatments: {
    items: [ /* tedavi listesi */ ],
    selectedTreatment: { /* seçili tedavi detayları */ },
    loading: false,
    error: null
  },
  reminders: {
    items: [ /* hatırlatıcı listesi */ ],
    selectedReminder: { /* seçili hatırlatıcı detayları */ },
    loading: false,
    error: null
  },
  dentists: {
    items: [ /* diş hekimi listesi */ ],
    selectedDentist: { /* seçili diş hekimi detayları */ },
    loading: false,
    error: null
  },
  ui: {
    theme: "light",
    language: "tr",
    notifications: [ /* bildirim listesi */ ]
  }
}
```

### Yerel Bileşen Durumu

Global state'e eklenmesi gerekmeyen durumlar, yerel bileşen durumu (local component state) olarak yönetilir:

- Form girişleri
- Geçici UI durumları (açılır menüler, dialog'lar)
- Animasyon durumları
- Sayfalama ve sıralama tercihleri

## Navigasyon Yapısı

React Navigation kütüphanesi kullanılarak uygulanan navigasyon yapısı:

### Ana Tab Navigasyonu

```javascript
<Tab.Navigator>
  <Tab.Screen name="Anasayfa" component={HomeNavigator} />
  <Tab.Screen name="Tedaviler" component={TreatmentsNavigator} />
  <Tab.Screen name="Hatırlatıcılar" component={RemindersNavigator} />
  <Tab.Screen name="Profil" component={ProfileNavigator} />
</Tab.Navigator>
```

### Stack Navigasyon Örneği (Tedaviler)

```javascript
<Stack.Navigator>
  <Stack.Screen name="TreatmentsList" component={TreatmentsListScreen} />
  <Stack.Screen name="TreatmentDetail" component={TreatmentDetailScreen} />
  <Stack.Screen name="AddTreatment" component={AddTreatmentScreen} />
  <Stack.Screen name="EditTreatment" component={EditTreatmentScreen} />
</Stack.Navigator>
```

## API İletişimi

API iletişimi, Axios kütüphanesi kullanılarak yapılandırılmıştır:

```javascript
// apiClient.js
const apiClient = axios.create({
  baseURL: 'https://api.dentiremind.com/v1',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Token interceptor
apiClient.interceptors.request.use(
  (config) => {
    const token = store.getState().auth.token;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Hata işleme interceptor
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Yetkilendirme hatası - Token yenileme veya çıkış yapma
      store.dispatch(refreshToken());
    }
    return Promise.reject(error);
  }
);
```

## Offline Synchronization

DentiRemind uygulaması, çevrimdışı çalışabilme özelliğine sahiptir:

### Senkronizasyon Stratejisi

1. **Yerel Depolama**: Realm veritabanı kullanılarak verilerin cihazda saklanması
2. **İşlem Kuyruklama**: Çevrimdışıyken yapılan değişikliklerin bir kuyrukta saklanması
3. **Çakışma Çözümü**: Sunucu ve istemci verileri arasındaki çakışmaları yönetme stratejileri
4. **Senkronizasyon Tetikleyicileri**:
   - Uygulama çevrimiçi olduğunda
   - Uygulama ön plana geldiğinde
   - Kullanıcı manuel senkronizasyon istediğinde

```javascript
// Senkronizasyon servisi örneği
class SyncService {
  async syncData() {
    try {
      // 1. Yerel veritabanındaki değişiklikleri al
      const pendingChanges = await this.getPendingChanges();
      
      // 2. İnternet bağlantısını kontrol et
      if (!await this.isConnected()) {
        return false;
      }
      
      // 3. Değişiklikleri sunucuya gönder
      for (const change of pendingChanges) {
        await this.pushChange(change);
      }
      
      // 4. Sunucudan güncel verileri al
      await this.pullLatestData();
      
      return true;
    } catch (error) {
      this.logSyncError(error);
      return false;
    }
  }
  
  // Diğer metodlar...
}
```

## Performans Optimizasyonu

Mobil uygulamanın performansını optimize etmek için aşağıdaki stratejiler uygulanmıştır:

1. **Memo ve Callback Optimizasyonu**: `React.memo()`, `useCallback()` ve `useMemo()` kullanımı
2. **Lazy Loading**: Ekranların ve büyük bileşenlerin geç yüklenmesi
3. **Liste Optimizasyonu**: FlatList ve VirtualizedList kullanımı
4. **Image Optimizasyonu**: Resim boyutlarının ve formatlarının optimizasyonu
5. **Bundle Size Optimizasyonu**: Code splitting ve tree shaking

## Test Stratejisi

DentiRemind frontend'i için kapsamlı bir test stratejisi uygulanmıştır:

1. **Birim Testleri**: Jest ile bileşen ve işlev testleri
2. **Entegrasyon Testleri**: React Testing Library ile bileşen entegrasyonu testleri
3. **End-to-End Testleri**: Detox ile tam uygulama testleri
4. **UI Snapshot Testleri**: Görsel regresyonları tespit etmek için

```javascript
// Bileşen testi örneği
describe('TreatmentCard', () => {
  it('renders treatment information correctly', () => {
    const treatment = {
      id: '1',
      title: 'Diş Kontrolü',
      startDate: '2023-06-10T09:00:00Z',
      status: 'scheduled',
      // ...diğer özellikler
    };
    
    const { getByText } = render(<TreatmentCard treatment={treatment} />);
    
    expect(getByText('Diş Kontrolü')).toBeDefined();
    expect(getByText('10 Haziran 2023')).toBeDefined();
    expect(getByText('Planlandı')).toBeDefined();
  });
});
```

## Erişilebilirlik Uyumluluğu

DentiRemind uygulaması, WCAG (Web Content Accessibility Guidelines) erişilebilirlik standartlarına uygunluk için tasarlanmıştır:

1. **Ekran Okuyucu Desteği**: Tüm bileşenler için uygun `accessibilityLabel` ve `accessibilityHint` özellikleri
2. **Kontrast Oranları**: Yeterli metin-arka plan kontrastı
3. **Dokunmatik Hedef Boyutları**: En az 44x44 piksel dokunmatik hedefler
4. **Klavye Navigasyonu**: Tab odağı ve klavye kontrolleri
5. **Dinamik Metin Boyutları**: Sistem font boyutu değişikliklerine uyum

## Yerelleştirme (i18n)

Uygulama, çeşitli dil ve bölgelere uyarlanacak şekilde tasarlanmıştır:

```javascript
// i18n yapılandırması
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

i18n
  .use(initReactI18next)
  .init({
    resources: {
      tr: {
        translation: require('./locales/tr.json')
      },
      en: {
        translation: require('./locales/en.json')
      }
    },
    lng: 'tr',
    fallbackLng: 'tr',
    interpolation: {
      escapeValue: false
    }
  });

// Bileşende kullanım
function MyComponent() {
  const { t } = useTranslation();
  return <Text>{t('common.welcome')}</Text>;
}
```

## Tema ve Stil Yönetimi

DentiRemind, tutarlı bir kullanıcı arayüzü sağlamak için merkezi bir tema sistemi kullanmaktadır:

```javascript
// tema tanımlaması
const theme = {
  colors: {
    primary: '#2D72DB',
    secondary: '#19B8D2',
    background: '#FFFFFF',
    text: '#333333',
    error: '#E53935',
    success: '#43A047',
    warning: '#FFA000',
    // ...diğer renkler
  },
  typography: {
    fontFamily: {
      regular: 'Roboto-Regular',
      medium: 'Roboto-Medium',
      bold: 'Roboto-Bold',
    },
    fontSize: {
      small: 12,
      medium: 14,
      large: 16,
      xlarge: 20,
      xxlarge: 24,
    },
  },
  spacing: {
    xs: 4,
    s: 8,
    m: 16,
    l: 24,
    xl: 32,
  },
  borderRadius: {
    small: 4,
    medium: 8,
    large: 16,
  },
  // ...diğer tema değişkenleri
};
```

[İçindekiler Sayfasına Dön](giris.md) 