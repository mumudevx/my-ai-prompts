# API Referansı

DentiRemind uygulaması, RESTful bir API mimarisi kullanmaktadır. Bu bölümde, API'nin temel yapısı, endpoint'leri ve bu endpoint'lerin kullanımına ilişkin detaylı bilgiler yer almaktadır.

## API Genel Bakış

- **Base URL**: `https://api.dentiremind.com/v1`
- **Kimlik Doğrulama**: JWT (JSON Web Token)
- **İstek Formatı**: JSON
- **Yanıt Formatı**: JSON
- **Hata Formatı**: Standart HTTP durum kodları ve açıklayıcı hata mesajları

## Kimlik Doğrulama

DentiRemind API'si, güvenli erişim için JWT tabanlı bir kimlik doğrulama sistemi kullanmaktadır.

### JWT Kullanımı

Tüm API isteklerinde (kimlik doğrulama endpoint'leri hariç), `Authorization` başlığında bir JWT token'ı gönderilmelidir:

```
Authorization: Bearer <token>
```

### Token Alımı

```http
POST /auth/login
Content-Type: application/json

{
  "email": "kullanici@ornek.com",
  "password": "guclu_sifre123"
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": 3600,
    "user": {
      "id": "60a1e2c05e4c2a0015d6a1a1",
      "email": "kullanici@ornek.com",
      "firstName": "Ahmet",
      "lastName": "Yılmaz",
      "role": "user"
    }
  }
}
```

### Token Yenileme

```http
POST /auth/token
Content-Type: application/json

{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

## Endpoint'ler

### Kullanıcı Yönetimi

#### Kullanıcı Kayıt

```http
POST /users/register
Content-Type: application/json

{
  "email": "yeni_kullanici@ornek.com",
  "password": "guclu_sifre123",
  "firstName": "Mehmet",
  "lastName": "Demir",
  "birthDate": "1990-05-15",
  "gender": "male",
  "phoneNumber": "+905551234567"
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "user": {
      "id": "60a1e2c05e4c2a0015d6a1a2",
      "email": "yeni_kullanici@ornek.com",
      "firstName": "Mehmet",
      "lastName": "Demir"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

#### Kullanıcı Profili Getirme

```http
GET /users/profile
Authorization: Bearer <token>
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "user": {
      "id": "60a1e2c05e4c2a0015d6a1a1",
      "email": "kullanici@ornek.com",
      "firstName": "Ahmet",
      "lastName": "Yılmaz",
      "birthDate": "1985-10-20",
      "gender": "male",
      "phoneNumber": "+905551234567",
      "profileImage": "https://storage.dentiremind.com/profiles/user123.jpg",
      "settings": {
        "language": "tr",
        "notificationPreferences": {
          "email": true,
          "push": true,
          "sms": false
        },
        "timezone": "Europe/Istanbul"
      },
      "familyMembers": [
        {
          "id": "60a1e2c05e4c2a0015d6a1a3",
          "name": "Ayşe Yılmaz",
          "relation": "spouse",
          "birthDate": "1987-03-15",
          "gender": "female"
        }
      ]
    }
  }
}
```

#### Kullanıcı Profili Güncelleme

```http
PUT /users/profile
Authorization: Bearer <token>
Content-Type: application/json

{
  "firstName": "Ahmet",
  "lastName": "Öztürk",
  "phoneNumber": "+905559876543",
  "settings": {
    "language": "en",
    "notificationPreferences": {
      "email": true,
      "push": true,
      "sms": true
    }
  }
}
```

### Tedavi Yönetimi

#### Tedavi Listesi Alma

```http
GET /treatments
Authorization: Bearer <token>
```

**Opsiyonel Parametreler**:
- `status`: Tedavi durumu filtresi (scheduled, ongoing, completed, cancelled)
- `startDate`: Başlangıç tarihi filtresi (YYYY-MM-DD)
- `endDate`: Bitiş tarihi filtresi (YYYY-MM-DD)
- `familyMemberId`: Aile üyesi filtresi
- `limit`: Sayfalama limit değeri
- `offset`: Sayfalama offset değeri

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "treatments": [
      {
        "id": "60a1e2c05e4c2a0015d6a1b1",
        "title": "Diş Taşı Temizliği",
        "description": "6 aylık rutin diş taşı temizliği",
        "startDate": "2023-05-10T09:00:00Z",
        "endDate": "2023-05-10T10:00:00Z",
        "status": "completed",
        "dentist": {
          "id": "60a1e2c05e4c2a0015d6a1c1",
          "firstName": "Fatma",
          "lastName": "Aydın",
          "specialty": "Periodontoloji"
        },
        "category": {
          "id": "60a1e2c05e4c2a0015d6a1d1",
          "name": "Diş Temizliği"
        }
      },
      {
        "id": "60a1e2c05e4c2a0015d6a1b2",
        "title": "Diş Kanal Tedavisi",
        "description": "Sağ üst azı dişi kanal tedavisi",
        "startDate": "2023-06-15T14:00:00Z",
        "endDate": null,
        "status": "scheduled",
        "dentist": {
          "id": "60a1e2c05e4c2a0015d6a1c2",
          "firstName": "Mehmet",
          "lastName": "Kaya",
          "specialty": "Endodonti"
        },
        "category": {
          "id": "60a1e2c05e4c2a0015d6a1d2",
          "name": "Kanal Tedavisi"
        }
      }
    ],
    "totalCount": 12,
    "offset": 0,
    "limit": 10
  }
}
```

#### Tedavi Detayı Alma

```http
GET /treatments/{treatmentId}
Authorization: Bearer <token>
```

#### Yeni Tedavi Oluşturma

```http
POST /treatments
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Diş Dolgusu",
  "description": "Sol alt azı dişi dolgusu",
  "categoryId": "60a1e2c05e4c2a0015d6a1d3",
  "startDate": "2023-07-20T11:00:00Z",
  "status": "scheduled",
  "dentistId": "60a1e2c05e4c2a0015d6a1c2",
  "location": "Özel Dent Kliniği",
  "cost": {
    "amount": 1500,
    "currency": "TRY"
  },
  "familyMemberId": null,
  "notes": [
    {
      "content": "Lokal anestezi gerekli"
    }
  ]
}
```

#### Tedavi Güncelleme

```http
PUT /treatments/{treatmentId}
Authorization: Bearer <token>
Content-Type: application/json

{
  "status": "completed",
  "endDate": "2023-07-20T12:00:00Z",
  "notes": [
    {
      "content": "Tedavi başarıyla tamamlandı"
    }
  ]
}
```

#### Tedavi Silme

```http
DELETE /treatments/{treatmentId}
Authorization: Bearer <token>
```

### Hatırlatıcı Yönetimi

#### Hatırlatıcı Listesi Alma

```http
GET /reminders
Authorization: Bearer <token>
```

**Opsiyonel Parametreler**:
- `isActive`: Aktif hatırlatıcılar filtresi (true/false)
- `fromDate`: Başlangıç tarihi filtresi (YYYY-MM-DD)
- `toDate`: Bitiş tarihi filtresi (YYYY-MM-DD)
- `reminderType`: Hatırlatıcı türü filtresi
- `familyMemberId`: Aile üyesi filtresi
- `limit`: Sayfalama limit değeri
- `offset`: Sayfalama offset değeri

#### Hatırlatıcı Oluşturma

```http
POST /reminders
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "İlaç Hatırlatıcısı",
  "description": "Antibiyotik kullanımı",
  "reminderType": "medication",
  "dateTime": "2023-06-10T08:00:00Z",
  "recurrence": {
    "pattern": "daily",
    "interval": 1,
    "endDate": "2023-06-17T08:00:00Z"
  },
  "notificationSettings": {
    "beforeTime": [
      {
        "minutes": 15,
        "notificationType": "push"
      }
    ],
    "repeatInterval": 5
  },
  "treatmentId": "60a1e2c05e4c2a0015d6a1b2"
}
```

#### Hatırlatıcı Güncelleme

```http
PUT /reminders/{reminderId}
Authorization: Bearer <token>
Content-Type: application/json

{
  "isActive": false
}
```

### Diş Hekimi Yönetimi

#### Diş Hekimi Arama

```http
GET /dentists
Authorization: Bearer <token>
```

**Opsiyonel Parametreler**:
- `specialty`: Uzmanlık alanı filtresi
- `location`: Konum bazlı arama (lat,lng)
- `radius`: Konum arama yarıçapı (km)
- `query`: İsim veya klinik adı araması
- `limit`: Sayfalama limit değeri
- `offset`: Sayfalama offset değeri

#### Diş Hekimi Detayı

```http
GET /dentists/{dentistId}
Authorization: Bearer <token>
```

### Randevu Yönetimi

#### Randevu Listesi Alma

```http
GET /appointments
Authorization: Bearer <token>
```

**Opsiyonel Parametreler**:
- `status`: Randevu durumu filtresi
- `fromDate`: Başlangıç tarihi filtresi (YYYY-MM-DD)
- `toDate`: Bitiş tarihi filtresi (YYYY-MM-DD)
- `dentistId`: Diş hekimi filtresi
- `familyMemberId`: Aile üyesi filtresi
- `limit`: Sayfalama limit değeri
- `offset`: Sayfalama offset değeri

#### Randevu Oluşturma

```http
POST /appointments
Authorization: Bearer <token>
Content-Type: application/json

{
  "dentistId": "60a1e2c05e4c2a0015d6a1c1",
  "date": "2023-08-05",
  "startTime": "14:30",
  "endTime": "15:30",
  "purpose": "Kontrol muayenesi",
  "notes": "İlk muayene",
  "familyMemberId": null,
  "treatmentId": null,
  "createReminder": true
}
```

## Hata Yanıtları

DentiRemind API'si, aşağıdaki formatta standart hata yanıtları döndürür:

```json
{
  "status": "error",
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Email adresi geçerli değil",
    "details": [
      {
        "field": "email",
        "message": "Geçerli bir email adresi giriniz"
      }
    ]
  }
}
```

### Genel Hata Kodları

| Kod | HTTP Status | Açıklama |
|-----|------------|----------|
| `AUTHENTICATION_ERROR` | 401 | Kimlik doğrulama hatası |
| `AUTHORIZATION_ERROR` | 403 | Yetkilendirme hatası |
| `RESOURCE_NOT_FOUND` | 404 | Kaynak bulunamadı |
| `VALIDATION_ERROR` | 422 | Giriş doğrulama hatası |
| `SERVER_ERROR` | 500 | Sunucu hatası |
| `RATE_LIMIT_EXCEEDED` | 429 | İstek limiti aşıldı |

## API Rate Limiting

DentiRemind API'si, güvenlik ve performans nedenleriyle rate limiting uygulamaktadır:

- Kimlik doğrulamasız istekler: 30 istek/dakika
- Kimlik doğrulamalı istekler: 100 istek/dakika

Rate limit aşıldığında, API `429 Too Many Requests` hatası döndürür ve response header'da kalan süreyi belirtir:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1623456789
```

## Swagger/OpenAPI Dokümanı

API'nin tam Swagger/OpenAPI dokümanına aşağıdaki URL'den erişilebilir:

```
https://api.dentiremind.com/v1/docs
```

## API Versiyonlama

DentiRemind API'si, geriye dönük uyumluluk için versiyonlama kullanmaktadır:

- Mevcut versiyon: `v1`
- URL yoluyla versiyonlama: `/v1/resource`
- Eski versiyonlar en az 6 ay desteklenir
- Major versiyon değişikliklerinde 30 gün önceden bildirim yapılır

[İçindekiler Sayfasına Dön](giris.md) 