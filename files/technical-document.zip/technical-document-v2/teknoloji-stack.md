# Teknoloji Stack'i

DentiRemind uygulaması, modern ve güvenilir teknolojiler kullanılarak geliştirilmiştir. Bu bölümde, uygulamanın farklı katmanlarında kullanılan teknolojileri detaylı olarak inceleyeceğiz.

## Mobil Uygulama Teknolojileri

### Ana Framework: React Native

React Native, DentiRemind'ın ana mobil uygulama framework'ü olarak seçilmiştir. Bu seçimin avantajları:

- Cross-platform geliştirme (iOS ve Android)
- Geniş geliştirici topluluğu
- Zengin bileşen ekosistemi
- Native performans

### Kullanılan Kütüphaneler ve Araçlar

| Kütüphane/Araç | Kullanım Amacı |
|----------------|----------------|
| Redux | Durum yönetimi |
| React Navigation | Ekran navigasyonu |
| Axios | HTTP istekleri |
| Formik | Form yönetimi |
| react-native-push-notification | Bildirim yönetimi |
| Realm | Yerel veritabanı |
| Moment.js | Tarih ve zaman işlemleri |
| Victory Native | Veri görselleştirme ve grafikler |
| react-native-svg | SVG desteği |
| react-native-calendars | Takvim görünümleri |
| Jest | Birim testleri |
| Detox | End-to-end testler |

## Backend Teknolojileri

### Ana Platform: Node.js

Node.js, uygulamanın backend servisleri için temel platform olarak seçilmiştir:

- Asenkron, non-blocking I/O modeli
- Yüksek performans
- Aynı dil stack'i (JavaScript/TypeScript)
- Mikroservis mimarisine uygunluk

### Backend Framework: Express.js

Express.js, RESTful API'lar oluşturmak için kullanılan hafif ve esnek bir framework'tür:

- Middleware desteği
- Routing kolaylığı
- Yüksek performans
- Geniş ekosistem

### Veritabanları

#### Ana Veritabanı: MongoDB

- Döküman tabanlı NoSQL yapısı
- Şemasız esnek veri modeli
- Yüksek ölçeklenebilirlik
- Dağıtık mimari desteği

#### Önbellek: Redis

- Yüksek performanslı anahtar-değer deposu
- Oturum yönetimi
- Cache mekanizması
- Pub/Sub modeli ile gerçek zamanlı bildirimler

#### Arama ve Analitik: Elasticsearch

- Tam metin arama
- Gelişmiş sorgu yetenekleri
- Analitik ve raporlama

### Diğer Backend Araçlar

| Araç | Kullanım Amacı |
|------|----------------|
| Mongoose | MongoDB ODM |
| Passport.js | Kimlik doğrulama |
| JWT | Token tabanlı yetkilendirme |
| Winston | Loglama |
| Joi | API validasyonu |
| Bull | İş kuyruklama |
| Agenda | Zamanlanmış görevler |
| Mocha & Chai | Birim testleri |
| SuperTest | API testleri |

## DevOps ve Altyapı

### CI/CD

- **GitHub Actions**: Sürekli entegrasyon ve dağıtım
- **Fastlane**: Mobil uygulama release otomasyonu

### Konteynerizasyon

- **Docker**: Uygulama konteynerizasyonu
- **Kubernetes**: Konteyner orkestrasyon

### Cloud Hizmetleri

- **AWS**: Ana cloud platformu
  - **EC2**: Sunucu altyapısı
  - **S3**: Dosya depolama
  - **RDS**: Yedek ilişkisel veritabanı
  - **CloudWatch**: Monitoring
  - **CloudFront**: CDN

### Monitoring ve Analitik

- **Prometheus**: Metrik toplama
- **Grafana**: Metrik görselleştirme
- **Sentry**: Hata izleme
- **ELK Stack**: Log analizi

## Üçüncü Parti Servisler

### Bildirim Servisleri

- **Firebase Cloud Messaging (FCM)**: Push bildirimleri
- **Apple Push Notification Service (APNs)**: iOS bildirimleri

### Dış Servis Entegrasyonları

- **Stripe**: Ödeme işlemleri
- **SendGrid**: E-posta servisi
- **Twilio**: SMS bildirimleri
- **Google Calendar API**: Takvim entegrasyonu

## Geliştirme Ortamı

### Dil ve Araçlar

- **TypeScript**: Ana geliştirme dili
- **ESLint**: Kod kalitesi kontrolü
- **Prettier**: Kod formatlaması
- **Yarn**: Paket yöneticisi
- **Visual Studio Code**: Önerilen IDE

### API Dokümantasyonu

- **Swagger/OpenAPI**: API dokümantasyonu
- **Postman**: API test ve dokümantasyon

## Güvenlik Araçları

- **Helmet.js**: HTTP güvenlik başlıkları
- **Node Rate Limiter**: Rate limiting
- **bcrypt**: Şifre hashleme
- **OWASP ZAP**: Güvenlik testleri

Tüm bu teknolojiler, DentiRemind uygulamasının güvenilir, ölçeklenebilir ve yüksek performanslı olmasını sağlayacak şekilde seçilmiştir. Her bir teknoloji, uygulamanın spesifik ihtiyaçları ve gereksinimleri göz önünde bulundurularak değerlendirilmiş ve entegre edilmiştir.

[İçindekiler Sayfasına Dön](giris.md) 