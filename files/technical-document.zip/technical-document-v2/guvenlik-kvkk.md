# Güvenlik ve KVKK Uyumluluğu

DentiRemind uygulaması, kullanıcıların kişisel ve sağlık verilerini işlediği için güvenlik ve gizlilik konularına özel önem vermektedir. Bu bölümde, uygulamanın güvenlik mimarisi ve Kişisel Verilerin Korunması Kanunu (KVKK) uyumluluğu için alınan önlemler detaylandırılmıştır.

## Güvenlik Mimarisi

DentiRemind'ın güvenlik mimarisi, aşağıdaki temel prensiplere dayanmaktadır:

1. **Defense in Depth (Derinlemesine Savunma)**: Birden fazla güvenlik katmanı kullanarak, herhangi bir katmanda meydana gelebilecek güvenlik ihlallerine karşı koruma sağlamak
2. **Principle of Least Privilege (En Az Ayrıcalık Prensibi)**: Her bileşenin yalnızca görevini yerine getirmek için gereken minimum ayrıcalıklara sahip olması
3. **Secure by Design (Tasarımla Güvenli)**: Güvenlik gereksinimlerinin uygulamanın tasarım aşamasından itibaren dikkate alınması
4. **Privacy by Default (Varsayılan Gizlilik)**: Gizlilik korumasının varsayılan olarak en yüksek seviyede olması

### Güvenlik Katmanları

DentiRemind'ın güvenlik mimarisi, aşağıdaki katmanlardan oluşmaktadır:

#### 1. Ağ Güvenliği

- **HTTPS/TLS**: Tüm iletişim HTTPS üzerinden gerçekleştirilir, TLS 1.2 veya daha yüksek versiyonlar kullanılır
- **Web Application Firewall (WAF)**: Cloudflare WAF ile yaygın web saldırılarına karşı koruma
- **IP Kısıtlamaları**: Admin paneline yalnızca onaylanmış IP adreslerinden erişim
- **DDoS Koruması**: Cloudflare DDoS koruması ile dağıtık hizmet reddi saldırılarına karşı koruma

#### 2. Kimlik Doğrulama ve Yetkilendirme

- **JWT Tabanlı Kimlik Doğrulama**: Kısa ömürlü access token'lar ve daha uzun ömürlü refresh token'lar
- **Güçlü Şifre Politikası**: Minimum 8 karakter, büyük/küçük harf, sayı ve özel karakter gereksinimleri
- **Çok Faktörlü Kimlik Doğrulama (MFA)**: Hassas işlemler için (hesap silme, ödeme işlemleri) SMS veya e-posta doğrulaması
- **RBAC (Role-Based Access Control)**: Kullanıcının rolüne göre erişim kontrolü

#### 3. Veri Güvenliği

- **Veri Şifreleme (Transit)**: Tüm ağ iletişimi TLS ile şifrelenir
- **Veri Şifreleme (At Rest)**: Veritabanında hassas alanlar AES-256 ile şifrelenir
- **Disk Şifreleme**: Sunucu disklerinin şifrelenmesi
- **Maskeleme**: Kişisel sağlık verilerinin gerekli olmadığı durumlarda maskelenmesi

#### 4. Uygulama Güvenliği

- **Giriş Doğrulama**: Tüm kullanıcı girdileri sunucu tarafında doğrulanır
- **SQL Injection Koruması**: Parametre bağlama ve ORM kullanımı
- **XSS Koruması**: Giriş/çıkış sanitizasyonu ve Content Security Policy (CSP)
- **CSRF Koruması**: Anti-CSRF token'lar ile
- **Secure Headers**: Helmet.js ile güvenlik başlıklarının yapılandırılması

#### 5. Altyapı Güvenliği

- **Düzenli Güvenlik Güncellemeleri**: İşletim sistemi ve yazılım güncellemeleri
- **Güvenlik Duvarı**: Ağ seviyesinde güvenlik duvarı yapılandırması
- **Sunucu Sertleştirme**: Gereksiz servislerin devre dışı bırakılması ve yapılandırma optimizasyonu
- **Container Güvenliği**: Docker container'larının güvenli yapılandırılması

## Kimlik Doğrulama ve Yetkilendirme

### JWT Yapılandırması

DentiRemind, güvenli bir JWT yapılandırması kullanmaktadır:

```javascript
// JWT ayarları
const jwtConfig = {
  secret: process.env.JWT_SECRET,
  accessTokenExpiresIn: '15m',
  refreshTokenExpiresIn: '7d',
  algorithm: 'HS256',
  issuer: 'dentiremind.com',
  audience: 'dentiremind-app'
};

// Access token oluşturma
function generateAccessToken(user) {
  return jwt.sign(
    {
      sub: user._id,
      role: user.role,
      email: user.email
    },
    jwtConfig.secret,
    {
      expiresIn: jwtConfig.accessTokenExpiresIn,
      algorithm: jwtConfig.algorithm,
      issuer: jwtConfig.issuer,
      audience: jwtConfig.audience
    }
  );
}

// Token doğrulama middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ 
      success: false, 
      error: 'Yetkilendirme tokeni eksik' 
    });
  }
  
  jwt.verify(token, jwtConfig.secret, {
    algorithms: [jwtConfig.algorithm],
    issuer: jwtConfig.issuer,
    audience: jwtConfig.audience
  }, (err, user) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ 
          success: false, 
          error: 'Token süresi doldu',
          code: 'TOKEN_EXPIRED'
        });
      }
      
      return res.status(403).json({ 
        success: false, 
        error: 'Geçersiz token' 
      });
    }
    
    req.user = user;
    next();
  });
}
```

### Password Hashing

Kullanıcı şifreleri, bcrypt algoritması kullanılarak güvenli bir şekilde hash'lenir:

```javascript
// Şifre hash'leme
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(12);
  return bcrypt.hash(password, salt);
}

// Şifre doğrulama
async function verifyPassword(password, hashedPassword) {
  return bcrypt.compare(password, hashedPassword);
}

// Yeni kullanıcı oluşturma örneği
async function createUser(userData) {
  const hashedPassword = await hashPassword(userData.password);
  
  const user = new User({
    email: userData.email,
    passwordHash: hashedPassword,
    firstName: userData.firstName,
    lastName: userData.lastName,
    // Diğer kullanıcı bilgileri
  });
  
  return user.save();
}
```

## Veri Şifreleme

### Veritabanı Şifreleme

Mongoose şeması üzerinde eklenti kullanılarak hassas alanların otomatik şifrelenmesi:

```javascript
// Mongoose şifreleme eklentisi
const encryptionPlugin = require('mongoose-encryption');

// Şifreleme anahtarları
const encKey = process.env.ENCRYPTION_KEY;
const sigKey = process.env.SIGNING_KEY;

// Şifreleme seçenekleri
const encryptionOptions = {
  encryptionKey: encKey,
  signingKey: sigKey,
  encryptedFields: ['phoneNumber', 'birthDate', 'gender'],
  additionalAuthenticatedFields: ['email', 'firstName', 'lastName']
};

// Kullanıcı şemasına eklenti ekleme
UserSchema.plugin(encryptionPlugin, encryptionOptions);
```

### Dosya Şifreleme

Kullanıcı tarafından yüklenen dosyaların S3'te şifreli saklanması:

```javascript
// AWS S3 şifreli yükleme yapılandırması
const s3Config = {
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
  bucket: process.env.S3_BUCKET,
  serverSideEncryption: 'AES256'
};

// Şifreli dosya yükleme
async function uploadEncryptedFile(file, path) {
  const params = {
    Bucket: s3Config.bucket,
    Key: path,
    Body: file.buffer,
    ContentType: file.mimetype,
    ServerSideEncryption: s3Config.serverSideEncryption
  };
  
  return s3.upload(params).promise();
}
```

## Güvenlik Testleri ve Denetimleri

DentiRemind, düzenli güvenlik testleri ve denetimlerle güvenliğini sağlamaktadır:

1. **Otomatik Güvenlik Taramaları**: OWASP ZAP ve Nessus ile düzenli taramalar
2. **Penetrasyon Testleri**: Yılda iki kez dış uzmanlar tarafından penetrasyon testi
3. **Kod Güvenlik Analizi**: SonarQube ve Snyk ile sürekli kod güvenlik analizi
4. **Bağımlılık Taraması**: Güvenlik açığı bulunan bağımlılıkların tespiti ve güncellenmesi
5. **Güvenlik Olay Yönetimi**: Güvenlik olaylarının izlenmesi ve müdahale planı

## KVKK Uyumluluğu

DentiRemind, 6698 sayılı Kişisel Verilerin Korunması Kanunu'na uygun olarak tasarlanmıştır.

### Veri İşleme İlkeleri

DentiRemind, KVKK'nın aşağıdaki temel ilkelerine uygun hareket etmektedir:

1. **Hukuka ve dürüstlük kurallarına uygunluk**: Tüm veri işleme faaliyetleri ilgili yasal çerçeve içinde gerçekleştirilir
2. **Doğru ve güncel olma**: Kullanıcı verilerinin doğruluğu ve güncelliği için teknik önlemler alınır
3. **Belirli, açık ve meşru amaçlar için işleme**: Veriler yalnızca belirtilen amaçlar için işlenir
4. **İşlendikleri amaçla bağlantılı, sınırlı ve ölçülü olma**: Yalnızca gerekli olan veriler işlenir
5. **İlgili mevzuatta öngörülen veya işlendikleri amaç için gerekli olan süre kadar muhafaza edilme**: Veri saklama süreleri politikası uygulanır

### Veri Sahibi Hakları

DentiRemind, KVKK kapsamında veri sahiplerine aşağıdaki hakları sağlar:

1. **Kişisel verilerin işlenip işlenmediğini öğrenme hakkı**
2. **Kişisel verileri işlenmişse buna ilişkin bilgi talep etme hakkı**
3. **Kişisel verilerin işlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme hakkı**
4. **Yurt içinde veya yurt dışında kişisel verilerin aktarıldığı üçüncü kişileri bilme hakkı**
5. **Kişisel verilerin eksik veya yanlış işlenmiş olması hâlinde bunların düzeltilmesini isteme hakkı**
6. **KVKK ve ilgili diğer kanun hükümlerine uygun olarak işlenmiş olmasına rağmen, işlenmesini gerektiren sebeplerin ortadan kalkması hâlinde kişisel verilerin silinmesini veya yok edilmesini isteme hakkı**
7. **Düzeltme, silme ve yok edilme taleplerinin, kişisel verilerin aktarıldığı üçüncü kişilere bildirilmesini isteme hakkı**
8. **İşlenen verilerin münhasıran otomatik sistemler vasıtasıyla analiz edilmesi suretiyle kişinin kendisi aleyhine bir sonucun ortaya çıkmasına itiraz etme hakkı**
9. **Kişisel verilerin kanuna aykırı olarak işlenmesi sebebiyle zarara uğraması hâlinde zararın giderilmesini talep etme hakkı**

### Aydınlatma ve Rıza

DentiRemind, kullanıcılardan kişisel verilerin işlenmesi için açık rıza alır ve veri işleme faaliyetleri hakkında ayrıntılı bilgi sağlar:

1. **Gizlilik Politikası**: Uygulama içinde erişilebilen kapsamlı gizlilik politikası
2. **Aydınlatma Metni**: Kayıt sırasında ve veri toplama noktalarında sunulan aydınlatma metinleri
3. **Açık Rıza**: Kişisel ve özel nitelikli kişisel verilerin işlenmesi için açık rıza mekanizması
4. **Çerezler**: Çerez politikası ve çerez tercihleri yönetimi

### Veri Minimizasyonu ve Saklama Süresi

DentiRemind, veri minimizasyonu ilkesini benimser:

1. **Yalnızca Gerekli Veriler**: Sadece uygulamanın işlevselliği için gerekli veriler toplanır
2. **Veri Anonimleştirme**: Mümkün olan durumlarda veriler anonimleştirilir
3. **Veri Silme Mekanizması**: Kullanıcılar kendi verilerini silebilir
4. **Saklama Süreleri**: Verilerin saklama süreleri belirlenmiş ve dokümante edilmiştir:
   - Kullanıcı hesap verileri: Hesap aktif olduğu sürece
   - İnaktif hesaplar: 24 ay sonra anonimleştirme, 36 ay sonra silme
   - Tedavi kayıtları: Tedavinin tamamlanmasından 5 yıl sonra anonimleştirme
   - Ödeme bilgileri: Yasal saklama süresi boyunca (10 yıl)
   - Log kayıtları: 6 ay

### Veri İhlali Bildirimi

KVKK kapsamında, veri ihlali durumunda aşağıdaki adımlar uygulanır:

1. **İhlal Tespiti**: Güvenlik izleme sistemleri ile olası ihlallerin hızlı tespiti
2. **Risk Değerlendirmesi**: İhlalin kapsamı ve etkisinin değerlendirilmesi
3. **Kişisel Verileri Koruma Kurulu Bildirimi**: 72 saat içerisinde Kurul'a bildirim
4. **İlgili Kişilere Bildirim**: Yüksek risk içeren ihlallerde ilgili kişilere bildirim
5. **İyileştirme Önlemleri**: İhlal sonrası sistemlerin güçlendirilmesi

## GDPR Uyumluluğu

DentiRemind, Avrupa Birliği'nin Genel Veri Koruma Tüzüğü (GDPR) ile de uyumludur. GDPR uyumluluğu kapsamında:

1. **Veri İşleme Kaydı**: Tüm veri işleme faaliyetlerinin kaydı tutulur
2. **Gizlilik Etki Değerlendirmesi**: Yüksek riskli işlemler için değerlendirme yapılır
3. **Tasarımla ve Varsayılan Olarak Veri Koruma**: Sistemler gizlilik odaklı tasarlanır
4. **Veri Taşınabilirliği**: Kullanıcılar verilerini yapılandırılmış bir formatta alabilir
5. **Çocuklara Yönelik Korumalar**: 18 yaş altı kullanıcılar için ebeveyn onayı

## Güvenlik Yapılandırma Örnekleri

### Content Security Policy (CSP)

```javascript
// Helmet.js ile CSP yapılandırması
app.use(
  helmet.contentSecurityPolicy({
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://cdn.dentiremind.com", "https://analytics.dentiremind.com"],
      styleSrc: ["'self'", "https://fonts.googleapis.com", "'unsafe-inline'"],
      imgSrc: ["'self'", "https://storage.dentiremind.com", "data:"],
      connectSrc: ["'self'", "https://api.dentiremind.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
      formAction: ["'self'"],
      upgradeInsecureRequests: [],
    },
  })
);
```

### CORS Yapılandırması

```javascript
// CORS yapılandırması
const corsOptions = {
  origin: function (origin, callback) {
    // İzin verilen kaynaklar
    const allowedOrigins = [
      'https://dentiremind.com',
      'https://www.dentiremind.com',
      'https://app.dentiremind.com'
    ];
    
    // Tarayıcıdan olmayan (örn. Mobile app) istekler için
    if (!origin || allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('CORS politikası tarafından engellendi'));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['X-Total-Count', 'X-Rate-Limit-Remaining'],
  credentials: true,
  maxAge: 86400 // 24 saat
};

app.use(cors(corsOptions));
```

### Rate Limiting

```javascript
// Rate limiting yapılandırması
const rateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 dakika
  max: 100, // IP başına 15 dakikada 100 istek
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    res.status(429).json({
      success: false,
      error: 'İstek limiti aşıldı, lütfen daha sonra tekrar deneyin',
      code: 'RATE_LIMIT_EXCEEDED'
    });
  },
  keyGenerator: (req) => {
    // Kullanıcı kimliği varsa, IP adresi yerine kullanıcı kimliğini kullan
    if (req.user && req.user.sub) {
      return req.user.sub;
    }
    
    return req.ip;
  }
});

// Login ve kayıt gibi hassas rotalar için daha sıkı limitler
const authLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 saat
  max: 10, // IP başına saatte 10 istek
  message: {
    success: false,
    error: 'Çok fazla giriş denemesi, lütfen 1 saat sonra tekrar deneyin',
    code: 'AUTH_RATE_LIMIT_EXCEEDED'
  }
});

// Limitleri uygula
app.use('/api/', rateLimiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);
```

## Güvenlik Kontrol Listesi

DentiRemind güvenlik uygulamaları, aşağıdaki kontrol listesine göre düzenli olarak değerlendirilir:

1. **Kimlik Doğrulama ve Yetkilendirme**
   - [ ] Güçlü şifre politikası uygulanıyor mu?
   - [ ] MFA seçeneği sunuluyor mu?
   - [ ] JWT'ler güvenli şekilde yapılandırılmış mı?
   - [ ] Oturum yönetimi güvenli mi?

2. **Veri Güvenliği**
   - [ ] Hassas veriler şifreleniyor mu?
   - [ ] Veritabanı güvenliği sağlanmış mı?
   - [ ] Veri sızıntısı önleme mekanizmaları var mı?
   - [ ] Yedekleme ve kurtarma prosedürleri test edildi mi?

3. **Ağ Güvenliği**
   - [ ] Tüm trafik HTTPS üzerinden mi?
   - [ ] API güvenliği sağlanmış mı?
   - [ ] Güvenlik duvarı kuralları güncel mi?
   - [ ] DDoS koruması aktif mi?

4. **Uygulama Güvenliği**
   - [ ] Giriş doğrulama mekanizmaları uygulanıyor mu?
   - [ ] XSS, CSRF korumaları var mı?
   - [ ] SQL Injection koruması var mı?
   - [ ] Güvenli HTTP başlıkları ayarlanmış mı?

5. **KVKK ve GDPR Uyumluluğu**
   - [ ] Aydınlatma metinleri güncel mi?
   - [ ] Açık rıza mekanizması uygun mu?
   - [ ] Veri saklama süreleri tanımlanmış mı?
   - [ ] Veri sahibi hakları destekleniyor mu?

## Güvenlik İletişim Kanalları

Güvenlik açıkları ve endişeleri için aşağıdaki kanallar kullanılabilir:

- **Güvenlik Açığı Bildirimi**: security@dentiremind.com
- **Sorumluluk Sahibi Açıklama Politikası**: https://dentiremind.com/security/disclosure
- **Bug Bounty Programı**: https://dentiremind.com/security/bugbounty

[İçindekiler Sayfasına Dön](giris.md) 