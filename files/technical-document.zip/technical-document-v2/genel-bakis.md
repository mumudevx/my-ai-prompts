# Genel Bakış

## DentiRemind Nedir?

DentiRemind, kullanıcıların diş tedavilerini ve kontrollerini takip etmelerini sağlayan, periyodik hatırlatıcılar kurmalarına olanak tanıyan kapsamlı bir mobil uygulamadır. Uygulama, diş sağlığı takibini kolaylaştırarak kullanıcıların tedavi süreçlerini aksatmamalarını hedefler.

## Temel Özellikler

1. **Kullanıcı Hesap Yönetimi**
   - Kayıt ve giriş işlemleri
   - Profil yönetimi
   - Çoklu cihaz desteği

2. **Diş Tedavi/Kontrol Kayıt Mekanizması**
   - Tedavi türlerine göre kategorizasyon
   - Geçmiş tedavilerin arşivlenmesi
   - Tedavi detayları ve notlar

3. **Hatırlatıcı Planlama ve Bildirim Sistemi**
   - Özelleştirilebilir bildirimler
   - Tekrarlayan hatırlatıcılar
   - Takvim entegrasyonu

4. **Diş Sağlığı Günlüğü ve Veri Görselleştirme**
   - Tedavi geçmişi istatistikleri
   - Grafiksel raporlama
   - İlerleme takibi

5. **Diş Hekimi Randevu Entegrasyonu**
   - Hekimlerle doğrudan iletişim
   - Randevu talep etme ve yönetme
   - Hekim değerlendirmeleri

## Hedef Kullanıcılar

Bu uygulamanın temel hedef kullanıcıları:

- Düzenli diş kontrolü yaptırması gereken bireyler
- Uzun süreli diş tedavisi gören hastalar
- Diş sağlığı konusunda düzenli takip yapmak isteyen kişiler
- Aileleri için diş sağlığı takibi yapmak isteyen ebeveynler

## Teknik Mimarinin Özeti

DentiRemind, modern bir mimari üzerine inşa edilmiştir:

- **Client-Server Mimarisi**: Mobil uygulama (istemci) ve bulut tabanlı sunucu
- **Mikroservis Yaklaşımı**: Ölçeklenebilir ve bakımı kolay servisler
- **RESTful API**: Standardize edilmiş veri alışverişi
- **Gerçek Zamanlı Bildirimler**: Push notification sistemi
- **Güvenli Veri Depolama**: Şifrelenmiş kullanıcı verileri ve KVKK uyumluluğu

Bu genel bakış, DentiRemind uygulamasının kapsamını ve temel özelliklerini tanıtmaktadır. Daha detaylı teknik bilgiler için ilgili bölümlere göz atabilirsiniz.

[İçindekiler Sayfasına Dön](giris.md) 