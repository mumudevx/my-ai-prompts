# Entegrasyon Kılavuzu

Bu bölüm, DentiRemind uygulamasının diş hekimi sistemleri, takvim uygulamaları ve diğer sağlık hizmeti platformları ile entegrasyonu için gerekli bilgileri içermektedir. Geliştiriciler, bu kılavuzu kullanarak DentiRemind'ı mevcut sistemlerle entegre edebilirler.

## API Entegrasyon Genel Bakış

DentiRemind, üçüncü taraf uygulamalarla entegrasyon için aşağıdaki yöntemleri sunar:

1. **RESTful API**: HTTP tabanlı standart entegrasyon
2. **Webhook'lar**: Gerçek zamanlı olay bildirimleri
3. **OAuth 2.0 Kimlik Doğrulama**: Güvenli üçüncü taraf erişimi
4. **Mobil Deep Link**: Mobil uygulama entegrasyonu

## RESTful API Entegrasyonu

### API Erişimi Alma

DentiRemind API'sine erişim için şu adımları izleyin:

1. [Geliştirici Portalına](https://developer.dentiremind.com) kaydolun
2. Yeni bir uygulama oluşturun ve gerekli erişim izinlerini seçin
3. API anahtarınızı ve client secret'ınızı alın
4. OAuth 2.0 akışını entegrasyonunuza ekleyin

### Kimlik Doğrulama

Tüm API istekleri OAuth 2.0 kullanılarak doğrulanmalıdır:

```http
POST /oauth/token
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&
client_id=YOUR_CLIENT_ID&
client_secret=YOUR_CLIENT_SECRET&
scope=read:treatments write:appointments
```

**Örnek Yanıt:**

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 7200,
  "scope": "read:treatments write:appointments"
}
```

Alınan token, tüm API isteklerinde `Authorization` başlığında kullanılmalıdır:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Diş Hekimi Sistemleri İçin Entegrasyon Uç Noktaları

#### 1. Randevu Senkronizasyonu

Diş hekimi sistemlerinden randevuları DentiRemind'a aktarmak için:

```http
POST /api/v1/integrations/appointments/sync
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "appointments": [
    {
      "externalId": "appt-12345",
      "patientExternalId": "patient-54321",
      "dentistExternalId": "dentist-98765",
      "title": "Diş Kontrolü",
      "description": "6 aylık rutin kontrol",
      "startDateTime": "2023-06-15T10:00:00Z",
      "endDateTime": "2023-06-15T10:30:00Z",
      "status": "confirmed",
      "location": {
        "name": "Merkez Klinik",
        "address": "Atatürk Cad. No:123, İstanbul",
        "coordinates": {
          "latitude": 41.0082,
          "longitude": 28.9784
        }
      }
    }
  ]
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "processedCount": 1,
    "failedCount": 0,
    "appointmentMappings": [
      {
        "externalId": "appt-12345",
        "dentiremindId": "60a1e2c05e4c2a0015d6a1f1"
      }
    ]
  }
}
```

#### 2. Hasta Eşleştirme

Diş hekimi sistemindeki hastaları DentiRemind kullanıcılarıyla eşleştirmek için:

```http
POST /api/v1/integrations/patients/match
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "patients": [
    {
      "externalId": "patient-54321",
      "email": "hasta@ornek.com",
      "phoneNumber": "+905551234567",
      "firstName": "Ayşe",
      "lastName": "Yılmaz",
      "birthDate": "1985-03-15"
    }
  ]
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "matches": [
      {
        "externalId": "patient-54321",
        "matchStatus": "matched",
        "dentiremindUserId": "60a1e2c05e4c2a0015d6a1a1"
      }
    ],
    "unmatched": []
  }
}
```

#### 3. Tedavi Bilgisi Gönderme

Tamamlanan veya planlanmış tedavi bilgilerini DentiRemind'a göndermek için:

```http
POST /api/v1/integrations/treatments
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "patientExternalId": "patient-54321",
  "treatments": [
    {
      "externalId": "treatment-67890",
      "title": "Kanal Tedavisi",
      "description": "Sağ üst azı dişi kanal tedavisi",
      "category": "Endodonti",
      "startDate": "2023-06-15",
      "endDate": "2023-06-29",
      "status": "ongoing",
      "notes": "Üç seans sürecek bir tedavi",
      "followUpRequired": true,
      "followUpDetails": {
        "type": "Kontrol",
        "recommendedDate": "2023-07-15"
      },
      "attachments": [
        {
          "name": "röntgen.jpg",
          "contentType": "image/jpeg",
          "contentUrl": "https://example.com/xray123.jpg"
        }
      ]
    }
  ]
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "processedCount": 1,
    "failedCount": 0,
    "treatmentMappings": [
      {
        "externalId": "treatment-67890",
        "dentiremindId": "60a1e2c05e4c2a0015d6a1b2"
      }
    ]
  }
}
```

### Takvim Entegrasyonu

DentiRemind, Google Takvim ve Apple Takvim gibi takvim sistemleriyle entegrasyon sağlar.

#### 1. Takvim Etkinliği Oluşturma

```http
POST /api/v1/integrations/calendar/events
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "userId": "60a1e2c05e4c2a0015d6a1a1",
  "calendarType": "google",
  "event": {
    "treatmentId": "60a1e2c05e4c2a0015d6a1b2",
    "title": "Diş Kontrolü - Dr. Mehmet Kaya",
    "description": "6 aylık rutin kontrol muayenesi",
    "startDateTime": "2023-08-10T14:30:00Z",
    "endDateTime": "2023-08-10T15:00:00Z",
    "location": "Özel Dent Kliniği, Ankara",
    "reminder": {
      "minutes": 30
    }
  }
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "eventId": "123456789",
    "calendarId": "primary",
    "htmlLink": "https://www.google.com/calendar/event?eid=123456789"
  }
}
```

#### 2. Takvim Senkronizasyonu Ayarları

```http
PUT /api/v1/users/settings/calendar-sync
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "userId": "60a1e2c05e4c2a0015d6a1a1",
  "calendarSync": {
    "google": {
      "enabled": true,
      "calendarId": "primary",
      "syncAppointments": true,
      "syncTreatments": true,
      "reminders": [
        {
          "method": "email",
          "minutes": 1440
        },
        {
          "method": "popup",
          "minutes": 60
        }
      ]
    },
    "apple": {
      "enabled": false
    }
  }
}
```

## Webhook Entegrasyonu

DentiRemind, belirli olaylar gerçekleştiğinde üçüncü taraf sistemlere bildirim göndermek için webhook'lar kullanır.

### Webhook URL Kaydetme

```http
POST /api/v1/integrations/webhooks
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "url": "https://example.com/dentiremind-webhook",
  "events": [
    "appointment.created",
    "appointment.updated",
    "appointment.cancelled",
    "treatment.created",
    "treatment.updated",
    "treatment.completed"
  ],
  "secret": "your-webhook-secret"
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "webhookId": "wh_123456789",
    "url": "https://example.com/dentiremind-webhook",
    "events": [
      "appointment.created",
      "appointment.updated",
      "appointment.cancelled",
      "treatment.created",
      "treatment.updated",
      "treatment.completed"
    ]
  }
}
```

### Webhook Bildirimi Örneği

Bir olay gerçekleştiğinde, DentiRemind kayıtlı webhook URL'sine aşağıdaki formatta bir HTTP POST isteği gönderir:

```json
{
  "id": "evt_123456789",
  "event": "appointment.created",
  "createdAt": "2023-06-15T10:30:00Z",
  "data": {
    "appointment": {
      "id": "60a1e2c05e4c2a0015d6a1f1",
      "patientId": "60a1e2c05e4c2a0015d6a1a1",
      "dentistId": "60a1e2c05e4c2a0015d6a1c1",
      "title": "Diş Kontrolü",
      "startDateTime": "2023-07-10T09:00:00Z",
      "endDateTime": "2023-07-10T09:30:00Z",
      "status": "confirmed"
    }
  }
}
```

### Webhook Güvenliği

Webhook istekleri, aşağıdaki imzalama algoritması kullanılarak doğrulanmalıdır:

1. DentiRemind, her webhook isteğiyle birlikte `X-DentiRemind-Signature` başlığını gönderir
2. Bu imza, isteğin gövdesinin HMAC-SHA256 karması ve webhook kaydı sırasında belirtilen secret kullanılarak oluşturulur
3. Alıcı sistem, aynı algoritmayı kullanarak imzayı doğrulamalıdır

```javascript
// Webhook imza doğrulama örneği (Node.js)
const crypto = require('crypto');

function verifyWebhookSignature(payload, signature, secret) {
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

// Express.js middleware örneği
function webhookMiddleware(req, res, next) {
  const signature = req.headers['x-dentiremind-signature'];
  const payload = JSON.stringify(req.body);
  const secret = process.env.WEBHOOK_SECRET;
  
  if (!signature) {
    return res.status(401).json({ error: 'Signature eksik' });
  }
  
  try {
    const isValid = verifyWebhookSignature(payload, signature, secret);
    
    if (!isValid) {
      return res.status(401).json({ error: 'Geçersiz imza' });
    }
    
    next();
  } catch (error) {
    console.error('Webhook doğrulama hatası:', error);
    return res.status(500).json({ error: 'Webhook doğrulama hatası' });
  }
}
```

## Mobil Uygulama Entegrasyonu

DentiRemind, mobil uygulamalar için deep link desteği sunar:

### Deep Link Formatı

```
dentiremind://treatments/{treatmentId}
dentiremind://appointments/{appointmentId}
dentiremind://reminders/{reminderId}
dentiremind://profile
```

### Universal Link Desteği

iOS 9 ve üzeri için Universal Link desteği de mevcuttur:

```
https://app.dentiremind.com/treatments/{treatmentId}
https://app.dentiremind.com/appointments/{appointmentId}
https://app.dentiremind.com/reminders/{reminderId}
https://app.dentiremind.com/profile
```

### Deep Link Oluşturma API'si

```http
POST /api/v1/integrations/deeplinks
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "type": "treatment",
  "id": "60a1e2c05e4c2a0015d6a1b2",
  "userId": "60a1e2c05e4c2a0015d6a1a1",
  "expiresIn": 86400
}
```

**Başarılı Yanıt:**

```json
{
  "status": "success",
  "data": {
    "deepLink": "dentiremind://treatments/60a1e2c05e4c2a0015d6a1b2?auth=abcdef123456",
    "universalLink": "https://app.dentiremind.com/treatments/60a1e2c05e4c2a0015d6a1b2?auth=abcdef123456",
    "expiresAt": "2023-06-16T10:30:00Z"
  }
}
```

## Sağlık Kayıt Sistemleri Entegrasyonu

DentiRemind, FHIR (Fast Healthcare Interoperability Resources) standardını destekleyerek EHR (Electronic Health Record) sistemleriyle entegrasyonu kolaylaştırır.

### FHIR Kaynakları Desteği

- Patient (Hasta)
- Practitioner (Diş Hekimi)
- Appointment (Randevu)
- Procedure (Tedavi)
- MedicationRequest (İlaç)
- Condition (Diş/Ağız Sağlığı Durumu)

### FHIR Endpoint Örneği

```http
GET /api/v1/fhir/Patient/{id}
Accept: application/fhir+json
Authorization: Bearer YOUR_ACCESS_TOKEN
```

**Örnek Yanıt (FHIR Patient Kaynağı):**

```json
{
  "resourceType": "Patient",
  "id": "60a1e2c05e4c2a0015d6a1a1",
  "identifier": [
    {
      "system": "https://dentiremind.com/fhir/identifiers/user",
      "value": "60a1e2c05e4c2a0015d6a1a1"
    }
  ],
  "active": true,
  "name": [
    {
      "use": "official",
      "family": "Yılmaz",
      "given": ["Ayşe"]
    }
  ],
  "telecom": [
    {
      "system": "email",
      "value": "hasta@ornek.com",
      "use": "home"
    },
    {
      "system": "phone",
      "value": "+905551234567",
      "use": "mobile"
    }
  ],
  "gender": "female",
  "birthDate": "1985-03-15"
}
```

## Yaygın Entegrasyon Senaryoları

### Senaryo 1: Diş Hekimi Yönetim Sistemi Entegrasyonu

Diş hekimi yönetim sistemi, aşağıdaki adımlar izlenerek DentiRemind ile entegre edilebilir:

1. **Başlangıç Kurulumu**
   - Geliştirici portalında uygulama kaydı
   - API anahtarları oluşturma
   - Webhook URL'sini kaydetme

2. **Hasta Eşleştirme**
   - Diş hekimi sisteminden hastaları alma
   - DentiRemind kullanıcılarıyla eşleştirme

3. **Randevu Senkronizasyonu**
   - Yeni randevular oluşturulduğunda DentiRemind'a gönderme
   - Randevu güncellemeleri ve iptalleri için webhook'ları dinleme

4. **Tedavi Bilgisi Aktarımı**
   - Tamamlanan tedavileri DentiRemind'a aktarma
   - Tedavi planlarını senkronize etme

### Senaryo 2: Takvim Uygulaması Entegrasyonu

1. **Kullanıcı İzni Alma**
   - OAuth 2.0 ile takvim servisine erişim izni
   - İzin kapsamını belirleme (okuma/yazma)

2. **Randevu/Hatırlatıcı Senkronizasyonu**
   - DentiRemind randevularını takvime ekleme
   - Takvim güncellemelerini dinleme

3. **İki Yönlü Senkronizasyon**
   - Takvimde yapılan değişiklikleri DentiRemind'a aktarma
   - Çakışmaları algılama ve çözme

## Entegrasyon Test Araçları

DentiRemind, entegrasyonları test etmek için aşağıdaki araçları sunar:

1. **Sandbox Ortamı**
   - Test API anahtarları
   - Örnek veri
   - Sıfırlama özelliği

2. **Webhook Tester**
   - Test webhook olayları tetikleme
   - Webhook yanıtlarını izleme

3. **API Explorer**
   - İnteraktif API dokümantasyonu
   - İstek/yanıt örnekleri
   - API isteklerini doğrudan test etme

## Sık Karşılaşılan Sorunlar ve Çözümleri

### 1. Kimlik Doğrulama Sorunları

**Sorun**: "Invalid token" veya "Expired token" hataları
**Çözüm**: Token'ın süresi dolmuş olabilir. Access token'ı yenileme flow'unu kullanarak yeni bir token alın.

### 2. Webhook Alınamıyor

**Sorun**: Webhook çağrıları alınmıyor
**Çözüm**:
- Webhook URL'inizin genel olarak erişilebilir olduğundan emin olun
- Firewall ayarlarını kontrol edin
- SSL sertifikasının geçerli olduğunu doğrulayın
- Webhook URL'sini doğru formatta kaydettiğinizi kontrol edin

### 3. Eşleştirme Sorunları

**Sorun**: Hasta-kullanıcı eşleştirmesi başarısız oluyor
**Çözüm**:
- Eşleştirme kriterlerini genişletin (sadece e-posta yerine telefon+isim gibi)
- Doğum tarihi formatını kontrol edin (YYYY-MM-DD)
- Karakter kodlaması sorunları için ad-soyad alanlarını kontrol edin

## Destek ve Kaynaklar

- **API Dokümantasyonu**: [https://developer.dentiremind.com/docs](https://developer.dentiremind.com/docs)
- **Entegrasyon Örnekleri**: [https://developer.dentiremind.com/examples](https://developer.dentiremind.com/examples)
- **SDKs**:
  - [JavaScript SDK](https://github.com/dentiremind/dentiremind-js)
  - [PHP SDK](https://github.com/dentiremind/dentiremind-php)
  - [Python SDK](https://github.com/dentiremind/dentiremind-python)
- **Destek**: integration-support@dentiremind.com

[İçindekiler Sayfasına Dön](giris.md) 