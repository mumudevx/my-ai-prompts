# Backend Mimarisi

DentiRemind uygulamasının backend mimarisi, güvenilir, ölçeklenebilir ve sürdürülebilir bir şekilde tasarlanmıştır. Bu bölümde, backend sisteminin teknik detayları, bileşenleri ve mimarisi ele alınmaktadır.

## Genel Mimari Yaklaşım

DentiRemind backend mimarisi, mikroservis tabanlı bir yaklaşım benimseyerek aşağıdaki prensiplere dayalı olarak geliştirilmiştir:

- **Ayrıştırılmış Sorumluluklar**: Her servis, belirli bir iş fonksiyonundan sorumludur
- **Bağımsız Dağıtım**: Servisler bağımsız olarak güncellenebilir ve dağıtılabilir
- **Teknolojik Özerklik**: Her servis, ihtiyaçlarına en uygun teknolojileri kullanabilir
- **İzole Hata Alanları**: Bir servisteki hata, diğer servisleri etkilemez
- **Ölçeklenebilirlik**: Her servis bağımsız olarak ölçeklendirilebilir

## Mimari Katmanlar

DentiRemind backend mimarisi, aşağıdaki katmanlardan oluşmaktadır:

### 1. API Gateway Katmanı

API Gateway, tüm istemci isteklerinin giriş noktasıdır ve aşağıdaki işlevleri yerine getirir:

- **İstek Yönlendirme**: İstekleri ilgili mikroservislere yönlendirir
- **Yük Dengeleme**: Gelen trafiği mikroservislere dengeli bir şekilde dağıtır
- **Kimlik Doğrulama**: JWT token doğrulaması gerçekleştirir
- **Rate Limiting**: API isteklerini sınırlar
- **Caching**: Sık kullanılan yanıtları önbelleğe alır
- **Request/Response Dönüşümü**: İstek ve yanıt formatlarını dönüştürür

```javascript
// API Gateway Örnek Kod
const express = require('express');
const httpProxy = require('http-proxy');
const rateLimit = require('express-rate-limit');
const { authenticateToken } = require('./middleware/auth');

const app = express();
const proxy = httpProxy.createProxyServer();

// Rate limiting middleware
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 dakika
  max: 100, // IP başına 15 dakikada max 100 istek
  standardHeaders: true,
  legacyHeaders: false
});

// Tüm isteklerde rate limiting uygula
app.use(apiLimiter);

// Auth servisi yönlendirmesi (Kimlik doğrulama gerekmiyor)
app.use('/api/auth', (req, res) => {
  proxy.web(req, res, { target: 'http://auth-service:3000' });
});

// Korumalı rotalar
app.use('/api/treatments', authenticateToken, (req, res) => {
  proxy.web(req, res, { target: 'http://treatment-service:3001' });
});

app.use('/api/reminders', authenticateToken, (req, res) => {
  proxy.web(req, res, { target: 'http://reminder-service:3002' });
});

app.use('/api/analytics', authenticateToken, (req, res) => {
  proxy.web(req, res, { target: 'http://analytics-service:3003' });
});

// Hata yönetimi
proxy.on('error', (err, req, res) => {
  res.status(500).json({ 
    success: false, 
    error: 'Proxy sunucusu hatası',
    details: process.env.NODE_ENV === 'development' ? err.message : undefined 
  });
});

app.listen(8000, () => {
  console.log('API Gateway 8000 portunda çalışıyor');
});
```

### 2. Mikroservis Katmanı

DentiRemind backend mimarisi, aşağıdaki ana mikroservisleri içerir:

#### Auth Service (Kimlik Doğrulama Servisi)

- **Kullanıcı Kaydı ve Girişi**: Kullanıcı hesap yönetimi
- **Token Yönetimi**: JWT token oluşturma ve doğrulama
- **Profil Yönetimi**: Kullanıcı profil bilgilerinin yönetimi
- **Yetkilendirme**: Rol tabanlı erişim kontrolleri

```javascript
// Auth Service Controller Örneği
const UserModel = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

class AuthController {
  // Kullanıcı kaydı
  async register(req, res) {
    try {
      const { email, password, firstName, lastName } = req.body;
      
      // E-posta adresi kontrolü
      const existingUser = await UserModel.findOne({ email });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          error: 'Bu e-posta adresi zaten kullanılıyor'
        });
      }
      
      // Şifre hashleme
      const salt = await bcrypt.genSalt(12);
      const passwordHash = await bcrypt.hash(password, salt);
      
      // Yeni kullanıcı oluşturma
      const newUser = new UserModel({
        email,
        passwordHash,
        firstName,
        lastName,
        createdAt: new Date(),
        isActive: true,
        role: 'user'
      });
      
      await newUser.save();
      
      // Token oluşturma
      const accessToken = jwt.sign(
        { sub: newUser._id, email: newUser.email, role: newUser.role },
        process.env.JWT_SECRET,
        { expiresIn: '15m' }
      );
      
      const refreshToken = jwt.sign(
        { sub: newUser._id },
        process.env.JWT_REFRESH_SECRET,
        { expiresIn: '7d' }
      );
      
      res.status(201).json({
        success: true,
        data: {
          user: {
            id: newUser._id,
            email: newUser.email,
            firstName: newUser.firstName,
            lastName: newUser.lastName,
            role: newUser.role
          },
          tokens: {
            accessToken,
            refreshToken
          }
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Kullanıcı kaydı sırasında bir hata oluştu'
      });
    }
  }
  
  // Diğer auth metodları...
}
```

#### Treatment Service (Tedavi Servisi)

- **Tedavi Kayıtları**: Tedavi kayıtlarının oluşturulması ve yönetimi
- **Tedavi Kategorileri**: Tedavi tipi ve kategorilerinin yönetimi
- **Diş Hekimi Entegrasyonu**: Diş hekimleri ile tedavilerin ilişkilendirilmesi
- **Tedavi İstatistikleri**: Tedavi ile ilgili istatistiklerin hesaplanması

#### Reminder Service (Hatırlatıcı Servisi)

- **Hatırlatıcı Oluşturma**: Tedavilere ve kontrole bağlı hatırlatıcıların oluşturulması
- **Zamanlama Motoru**: Hatırlatıcıların zamanlaması ve tetiklenmesi
- **Tekrarlayan Hatırlatıcılar**: Periyodik hatırlatıcıların yönetimi
- **Bildirim Koordinasyonu**: Bildirim servisi ile entegrasyon

#### Notification Service (Bildirim Servisi)

- **Push Bildirimleri**: Firebase Cloud Messaging ile mobil bildirimleri
- **E-posta Bildirimleri**: E-posta gönderimi ve şablonları
- **SMS Bildirimleri**: SMS entegrasyonu
- **Bildirim Tercihleri**: Kullanıcı bazlı bildirim ayarları

#### Analytics Service (Analitik Servisi)

- **Kullanım İstatistikleri**: Uygulama kullanım metrikleri
- **Raporlama**: Kullanıcı ve tedavi raporları
- **Dashboard Verileri**: Yönetim paneli için metrikler
- **Veri Analitiği**: Kullanıcı davranışı ve tedavi trendleri

### 3. Veritabanı Katmanı

Her mikroservis, kendi özel veritabanını yönetir:

- **Auth Service DB**: Kullanıcı hesapları ve kimlik doğrulama bilgileri
- **Treatment Service DB**: Tedavi kayıtları ve meta veriler
- **Reminder Service DB**: Hatırlatıcı kayıtları ve zamanlama bilgileri
- **Notification Service DB**: Bildirim kayıtları ve şablonları
- **Analytics Service DB**: Analitik veriler ve raporlar

```javascript
// Mongoose Bağlantısı Örneği (Tedavi Servisi)
const mongoose = require('mongoose');
const logger = require('./logger');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,
      useFindAndModify: false,
      dbName: 'dentiremind_treatments'
    });
    
    logger.info(`MongoDB Bağlantısı Başarılı: ${conn.connection.host}`);
    
    // İndeksleri oluştur
    await setupIndexes();
    
    return conn;
  } catch (error) {
    logger.error(`MongoDB Bağlantı Hatası: ${error.message}`);
    process.exit(1);
  }
};

const setupIndexes = async () => {
  // Modellerdeki şemalar üzerinde indeksler oluştur
  const Treatment = mongoose.model('Treatment');
  await Treatment.createIndexes();
  
  logger.info('Veritabanı indeksleri oluşturuldu');
};

module.exports = connectDB;
```

### 4. Altyapı Servisleri

Uygulamanın temel altyapısını oluşturan servisler:

- **Service Discovery**: Mikroservislerin birbirini bulmasını sağlar (Consul)
- **Configuration Server**: Merkezi yapılandırma yönetimi (Spring Cloud Config)
- **Message Broker**: Servisler arası asenkron iletişim (RabbitMQ)
- **Caching Server**: Önbellek servisi (Redis)
- **Log Aggregation**: Log toplama ve analiz (ELK Stack)
- **Monitoring**: Sistem izleme (Prometheus & Grafana)

## Servisler Arası İletişim

DentiRemind mikroservisleri, aşağıdaki iletişim yöntemlerini kullanır:

### 1. Senkron İletişim (REST API)

Servisler arasında doğrudan HTTP/REST çağrıları kullanılır:

```javascript
// Tedavi servisi üzerinden hatırlatıcı servisine istek
const axios = require('axios');

async function createReminderForTreatment(treatmentId, userId, reminderData) {
  try {
    const response = await axios.post(
      'http://reminder-service:3002/api/reminders',
      {
        treatmentId,
        userId,
        ...reminderData
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${serviceToken}`,
          'X-Service-Name': 'treatment-service'
        }
      }
    );
    
    return response.data;
  } catch (error) {
    logger.error(`Hatırlatıcı oluşturma hatası: ${error.message}`);
    throw new Error('Hatırlatıcı oluşturulamadı');
  }
}
```

### 2. Asenkron İletişim (Event-Driven)

Servisler, RabbitMQ üzerinden olayları yayınlar ve dinler:

```javascript
// RabbitMQ Üzerinden Event Publishing
const amqp = require('amqplib');

class EventBus {
  constructor() {
    this.connection = null;
    this.channel = null;
  }
  
  async connect() {
    this.connection = await amqp.connect(process.env.RABBITMQ_URL);
    this.channel = await this.connection.createChannel();
    
    // Exchange tanımla
    await this.channel.assertExchange('dentiremind', 'topic', { durable: true });
  }
  
  async publishEvent(routingKey, data) {
    if (!this.channel) {
      await this.connect();
    }
    
    const eventData = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      data
    };
    
    return this.channel.publish(
      'dentiremind',
      routingKey,
      Buffer.from(JSON.stringify(eventData)),
      { persistent: true }
    );
  }
  
  async subscribeToEvent(routingKey, callback) {
    if (!this.channel) {
      await this.connect();
    }
    
    // Queue oluştur
    const { queue } = await this.channel.assertQueue('', { exclusive: true });
    
    // Queue'yu exchange'e bağla
    await this.channel.bindQueue(queue, 'dentiremind', routingKey);
    
    // Mesajları dinle
    await this.channel.consume(queue, (msg) => {
      if (msg !== null) {
        try {
          const eventData = JSON.parse(msg.content.toString());
          callback(eventData);
          this.channel.ack(msg);
        } catch (error) {
          this.channel.nack(msg);
        }
      }
    });
  }
}

// Kullanım örneği
const eventBus = new EventBus();

// Tedavi oluşturulduğunda event yayınla
async function publishTreatmentCreatedEvent(treatment) {
  await eventBus.publishEvent('treatment.created', treatment);
}

// Hatırlatıcı servisinde tedavi olaylarını dinle
async function subscribeTreatmentEvents() {
  await eventBus.subscribeToEvent('treatment.*', (eventData) => {
    if (eventData.routingKey === 'treatment.created') {
      createReminderForNewTreatment(eventData.data);
    } else if (eventData.routingKey === 'treatment.updated') {
      updateRelatedReminders(eventData.data);
    }
  });
}
```

## API Tasarımı

DentiRemind, RESTful API tasarım prensiplerine uygun API'lar sunar:

### Endpoint Yapısı

```
/api/v1/auth                 # Kimlik doğrulama
/api/v1/users                # Kullanıcı işlemleri
/api/v1/treatments           # Tedavi işlemleri
/api/v1/treatments/:id       # Belirli bir tedavi
/api/v1/reminders            # Hatırlatıcı işlemleri
/api/v1/reminders/:id        # Belirli bir hatırlatıcı
/api/v1/categories           # Tedavi kategorileri
/api/v1/dentists             # Diş hekimi işlemleri
/api/v1/appointments         # Randevu işlemleri
```

### API Dokümantasyon Örneği

```javascript
/**
 * @swagger
 * /api/v1/treatments:
 *   post:
 *     summary: Yeni bir tedavi kaydı oluşturur
 *     tags: [Treatments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - title
 *               - categoryId
 *               - startDate
 *             properties:
 *               title:
 *                 type: string
 *                 description: Tedavi başlığı
 *               categoryId:
 *                 type: string
 *                 description: Tedavi kategorisi ID
 *               startDate:
 *                 type: string
 *                 format: date-time
 *                 description: Tedavi başlangıç tarihi
 *               endDate:
 *                 type: string
 *                 format: date-time
 *                 description: Tedavi bitiş tarihi (opsiyonel)
 *               description:
 *                 type: string
 *                 description: Tedavi açıklaması
 *               dentistId:
 *                 type: string
 *                 description: Diş hekimi ID (opsiyonel)
 *     responses:
 *       201:
 *         description: Tedavi başarıyla oluşturuldu
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     treatment:
 *                       $ref: '#/components/schemas/Treatment'
 *       400:
 *         description: Geçersiz giriş verileri
 *       401:
 *         description: Yetkilendirme hatası
 *       500:
 *         description: Sunucu hatası
 */
```

## Hata Yönetimi

DentiRemind backend servisleri, tutarlı bir hata yönetimi stratejisi kullanır:

```javascript
// Global hata yakalama middleware
app.use((err, req, res, next) => {
  // Hata log'u
  logger.error(`${req.method} ${req.url} - ${err.message}`, { 
    stack: err.stack,
    user: req.user ? req.user.sub : 'anonymous',
    requestId: req.id
  });
  
  // Hata türüne göre işlem
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      error: 'Doğrulama hatası',
      details: err.details || err.message,
      code: 'VALIDATION_ERROR'
    });
  }
  
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      error: 'Yetkisiz erişim',
      code: 'UNAUTHORIZED'
    });
  }
  
  if (err.name === 'NotFoundError') {
    return res.status(404).json({
      success: false,
      error: 'Kaynak bulunamadı',
      details: err.message,
      code: 'NOT_FOUND'
    });
  }
  
  // Varsayılan hata yanıtı
  const statusCode = err.statusCode || 500;
  const errorMessage = process.env.NODE_ENV === 'production' 
    ? 'Sunucu hatası'
    : err.message;
  
  res.status(statusCode).json({
    success: false,
    error: errorMessage,
    code: err.code || 'SERVER_ERROR'
  });
});
```

## Kod Organizasyonu

Her mikroservis, aşağıdaki klasör yapısına sahiptir:

```
service-name/
├── src/
│   ├── controllers/    # İstek yöneticileri
│   ├── models/         # Veri modelleri
│   ├── services/       # İş mantığı
│   ├── repositories/   # Veri erişimi
│   ├── middleware/     # Express middleware'leri
│   ├── routes/         # API rotaları
│   ├── utils/          # Yardımcı fonksiyonlar
│   ├── validators/     # Girdi doğrulayıcılar
│   ├── config/         # Konfigürasyon dosyaları
│   ├── events/         # Event handlers ve publishers
│   └── app.js          # Ana uygulama dosyası
├── tests/             # Test dosyaları
├── Dockerfile         # Docker yapılandırması
├── .env.example       # Örnek çevre değişkenleri
├── package.json       # Bağımlılıklar
└── README.md          # Servis dokümantasyonu
```

## Dağıtım Stratejisi

DentiRemind backend servisleri, Docker container'ları içinde paketlenir ve Kubernetes üzerinde çalıştırılır:

```dockerfile
# Örnek Dockerfile
FROM node:16-alpine

WORKDIR /usr/src/app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

# Uygulamayı çalıştırmadan önce veritabanı yedek alım scriptini ekle
COPY ./scripts/backup-db.sh /usr/local/bin/backup-db.sh
RUN chmod +x /usr/local/bin/backup-db.sh

# Healthcheck
HEALTHCHECK --interval=30s --timeout=5s --start-period=5s --retries=3 \
  CMD wget --no-verbose --tries=1 --spider http://localhost:${PORT}/health || exit 1

# Non-root kullanıcı ile çalıştır
USER node

ENV NODE_ENV=production
ENV PORT=3000

EXPOSE ${PORT}

CMD ["node", "src/app.js"]
```

## Güvenlik Önlemleri

Backend servislerinde uygulanan güvenlik önlemleri:

1. **API Güvenliği**: JWT tabanlı kimlik doğrulama ve yetkilendirme
2. **Veri Doğrulama**: Tüm girdilerin Joi kütüphanesi ile doğrulanması
3. **Güvenli Başlıklar**: Helmet.js ile güvenlik başlıklarının ayarlanması
4. **Rate Limiting**: API isteklerini sınırlama
5. **Input Sanitization**: XSS ve enjeksiyon saldırılarına karşı temizleme
6. **Şifreleme**: Hassas verilerin şifrelenmesi
7. **Audit Logging**: Güvenlik olaylarının loglanması

## Performans Optimizasyonu

Backend servislerinde uygulanan performans optimizasyonları:

1. **Veritabanı İndeksleme**: Sık sorgulanan alanlar için indeksler
2. **Önbellek Kullanımı**: Redis ile API yanıtları ve yaygın sorguların önbelleğe alınması
3. **İstek Sıkıştırma**: Gzip ve Brotli sıkıştırma
4. **Bağlantı Havuzları**: Veritabanı ve Redis bağlantı havuzları
5. **Asenkron İşleme**: CPU yoğun işlemlerin arka planda işlenmesi
6. **Veritabanı Projeksiyon**: Sorgularda yalnızca gerekli alanların seçilmesi

## Kaynak Yönetimi

Mikroservislerin kaynak yönetimi için Kubernetes yapılandırması:

```yaml
# Örnek Kubernetes deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: treatment-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: treatment-service
  template:
    metadata:
      labels:
        app: treatment-service
    spec:
      containers:
      - name: treatment-service
        image: dentiremind/treatment-service:1.0.0
        resources:
          requests:
            memory: "256Mi"
            cpu: "100m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        env:
        - name: MONGODB_URI
          valueFrom:
            secretKeyRef:
              name: mongodb-secret
              key: uri
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: jwt-secret
              key: secret
        ports:
        - containerPort: 3000
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 10
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 15
          periodSeconds: 20
```

## Veritabanı Migrasyonları

Veritabanı şema değişiklikleri, otomatik migrasyon araçları ile yönetilir:

```javascript
// migrate-mongo konfigürasyonu
const config = {
  mongodb: {
    url: process.env.MONGODB_URI,
    databaseName: 'dentiremind_treatments',
    options: {
      useNewUrlParser: true,
      useUnifiedTopology: true
    }
  },
  migrationsDir: 'migrations',
  changelogCollectionName: 'migrations_changelog',
  migrationFileExtension: '.js'
};

// Örnek migrasyon dosyası
module.exports = {
  async up(db) {
    // Yeni alan ekle
    await db.collection('treatments').updateMany({}, {
      $set: { isArchived: false }
    });
    
    // İndeks oluştur
    await db.collection('treatments').createIndex({ isArchived: 1 });
  },

  async down(db) {
    // Alanı kaldır
    await db.collection('treatments').updateMany({}, {
      $unset: { isArchived: "" }
    });
    
    // İndeksi kaldır
    await db.collection('treatments').dropIndex({ isArchived: 1 });
  }
};
```

## Sonuç

DentiRemind'ın backend mimarisi, modern yazılım geliştirme prensiplerine uygun olarak tasarlanmıştır. Mikroservis tabanlı yaklaşım, uygulamanın ölçeklenebilirliğini, bakım yapılabilirliğini ve esnekliğini artırmaktadır. Her servis, belirli bir iş fonksiyonundan sorumlu olarak, bağımsız geliştirme ve dağıtıma olanak tanır.

Bu mimari, hem mevcut gereksinimleri karşılamakta hem de gelecekteki büyüme için sağlam bir temel oluşturmaktadır. DentiRemind, bu mimari sayesinde, kullanıcı sayısı arttıkça ölçeklenebilir ve yeni özellikler eklendikçe genişleyebilir.

[İçindekiler Sayfasına Dön](giris.md) 