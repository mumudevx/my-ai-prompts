# Kurulum ve Kullanım

Bu bölümde, DentiRemind uygulamasının kurulum ve kullanımına ilişkin detaylı bilgiler sunulmaktadır. Geliştirme ortamından başlayarak, üretim ortamına dağıtıma kadar tüm adımlar kapsamlı bir şekilde ele alınmıştır.

## Geliştirme Ortamı Kurulumu

### Ön Koşullar

DentiRemind'ı geliştirmek için aşağıdaki yazılım ve araçlara ihtiyacınız vardır:

- **Node.js**: v14.x veya üzeri
- **MongoDB**: v4.4 veya üzeri
- **Redis**: v6.x veya üzeri
- **Git**: En son sürüm
- **Docker (opsiyonel)**: Konteynerize geliştirme için

#### Windows'ta Kurulum

1. [Node.js](https://nodejs.org/) resmi sitesinden indirip kurun
2. [MongoDB Community Edition](https://www.mongodb.com/try/download/community) indirip kurun
3. [Redis for Windows](https://github.com/microsoftarchive/redis/releases) indirip kurun
4. [Git for Windows](https://git-scm.com/download/win) indirip kurun

#### macOS'ta Kurulum

Homebrew kullanarak:

```bash
# Homebrew kurulumu (eğer kurulu değilse)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Node.js kurulumu
brew install node@14

# MongoDB kurulumu
brew tap mongodb/brew
brew install mongodb-community@4.4

# Redis kurulumu
brew install redis

# Git kurulumu
brew install git
```

#### Linux'ta Kurulum (Ubuntu/Debian)

```bash
# Node.js kurulumu
curl -fsSL https://deb.nodesource.com/setup_14.x | sudo -E bash -
sudo apt-get install -y nodejs

# MongoDB kurulumu
wget -qO - https://www.mongodb.org/static/pgp/server-4.4.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu $(lsb_release -cs)/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list
sudo apt-get update
sudo apt-get install -y mongodb-org

# Redis kurulumu
sudo apt-get install redis-server

# Git kurulumu
sudo apt-get install git
```

### Kaynak Kodunu İndirme

```bash
# Ana depoyu klonlama
git clone https://github.com/dentiremind/dentiremind.git
cd dentiremind

# Bağımlılıkları yükleme
npm install
```

### Backend Kurulumu

1. Öncelikle `.env.example` dosyasını `.env` olarak kopyalayın ve gerekli değişkenleri ayarlayın:

```bash
cp .env.example .env
```

2. .env dosyasını düzenleyin:

```
# Uygulama
NODE_ENV=development
PORT=5000
API_URL=http://localhost:5000
FRONTEND_URL=http://localhost:3000

# Veritabanı
MONGODB_URI=mongodb://localhost:27017/dentiremind
REDIS_URL=redis://localhost:6379

# JWT Ayarları
JWT_SECRET=your_jwt_secret_key
JWT_ACCESS_EXPIRATION=15m
JWT_REFRESH_EXPIRATION=7d

# Mail Ayarları
MAIL_HOST=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=user@example.com
MAIL_PASSWORD=your_mail_password
MAIL_FROM=noreply@dentiremind.com

# Bildirim Ayarları
FCM_PROJECT_ID=your_firebase_project_id
FCM_CLIENT_EMAIL=your_firebase_client_email
FCM_PRIVATE_KEY=your_firebase_private_key

# AWS S3 (Dosya Depolama)
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_REGION=eu-central-1
S3_BUCKET=dentiremind-dev

# Diğer Ayarlar
LOG_LEVEL=debug
ENCRYPT_KEY=your_encryption_key
```

3. Veritabanını başlatın:

```bash
# MongoDB servisini başlat
# Windows
net start MongoDB

# macOS
brew services start mongodb-community

# Linux
sudo systemctl start mongod
```

4. Redis servisini başlatın:

```bash
# Windows
redis-server

# macOS
brew services start redis

# Linux
sudo systemctl start redis
```

5. Veritabanı şemasını ve başlangıç verilerini oluşturun:

```bash
npm run seed
```

6. Backend uygulamasını başlatın:

```bash
npm run dev
```

### Mobile Uygulama Kurulumu

#### React Native Geliştirme Ortamı

1. React Native CLI'yi kurun:

```bash
npm install -g react-native-cli
```

2. Mobil uygulama klasörüne gidin:

```bash
cd mobile
```

3. Bağımlılıkları yükleme:

```bash
npm install
```

4. iOS için (sadece macOS):

```bash
cd ios
pod install
cd ..
```

5. `.env.example` dosyasını `.env` olarak kopyalayın ve düzenleyin:

```bash
cp .env.example .env
```

6. Uygulamayı başlatın:

```bash
# iOS için (sadece macOS)
npx react-native run-ios

# Android için
npx react-native run-android
```

## Docker ile Geliştirme Ortamı

DentiRemind, Docker kullanarak containerize edilmiş bir geliştirme ortamı sunar:

1. Docker ve Docker Compose'u kurun:
   - [Docker Desktop](https://www.docker.com/products/docker-desktop) (Windows/macOS için)
   - [Docker Engine](https://docs.docker.com/engine/install/) ve [Docker Compose](https://docs.docker.com/compose/install/) (Linux için)

2. Ana dizindeki `docker-compose.dev.yml` dosyasını kullanarak servisleri başlatın:

```bash
docker-compose -f docker-compose.dev.yml up
```

Bu komut, aşağıdaki servisleri başlatacaktır:

- **dentiremind-api**: Backend API servisi
- **dentiremind-mongodb**: MongoDB veritabanı
- **dentiremind-redis**: Redis önbelleği
- **dentiremind-mongo-express**: MongoDB yönetim arayüzü

MongoDB yönetim arayüzüne `http://localhost:8081` adresinden erişebilirsiniz.

## Üretim Ortamı Dağıtımı

### Backend Dağıtımı

#### 1. Sunucu Gereksinimleri

- **İşletim Sistemi**: Ubuntu 20.04 LTS veya üzeri
- **CPU**: 2 çekirdek minimum, 4 çekirdek önerilen
- **RAM**: 4 GB minimum, 8 GB önerilen
- **Disk**: 20 GB minimum, SSD önerilen

#### 2. Sunucu Hazırlığı

```bash
# Gerekli paketleri yükleyin
sudo apt update
sudo apt install -y nodejs npm mongodb redis-server nginx certbot python3-certbot-nginx

# Node.js'i güncelleyin
curl -fsSL https://deb.nodesource.com/setup_14.x | sudo -E bash -
sudo apt-get install -y nodejs

# PM2 global olarak yükleyin
sudo npm install -g pm2
```

#### 3. Kaynak Kodunu Dağıtma

```bash
# Deployment dizinine gidin
cd /var/www

# Projeyi klonlayın
sudo git clone https://github.com/dentiremind/dentiremind.git
cd dentiremind

# Bağımlılıkları yükleyin
sudo npm install --production

# .env dosyasını oluşturun
sudo cp .env.example .env
sudo nano .env
```

Üretim ortamı için `.env` dosyasını düzenleyin, özellikle:

```
NODE_ENV=production
PORT=5000
API_URL=https://api.dentiremind.com
FRONTEND_URL=https://app.dentiremind.com
```

#### 4. SSL Sertifikası Alma

```bash
sudo certbot --nginx -d api.dentiremind.com
```

#### 5. Nginx Yapılandırması

```bash
sudo nano /etc/nginx/sites-available/dentiremind-api
```

Aşağıdaki yapılandırmayı ekleyin:

```nginx
server {
    listen 80;
    server_name api.dentiremind.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name api.dentiremind.com;

    ssl_certificate /etc/letsencrypt/live/api.dentiremind.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.dentiremind.com/privkey.pem;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Nginx yapılandırmasını etkinleştirin:

```bash
sudo ln -s /etc/nginx/sites-available/dentiremind-api /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 6. PM2 ile Uygulamayı Başlatma

```bash
# Ecosystem dosyası oluşturma
cat > ecosystem.config.js << EOL
module.exports = {
  apps: [{
    name: 'dentiremind-api',
    script: 'src/server.js',
    instances: 'max',
    exec_mode: 'cluster',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production'
    }
  }]
};
EOL

# Uygulamayı başlatma
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

### Mobil Uygulama Dağıtımı

#### Android APK Oluşturma

1. `mobile/android/app/build.gradle` dosyasını düzenleyerek versionCode ve versionName değerlerini güncelleyin.

2. Release için keystore oluşturma (eğer mevcut değilse):

```bash
cd android/app
keytool -genkeypair -v -storetype PKCS12 -keystore dentiremind.keystore -alias dentiremind -keyalg RSA -keysize 2048 -validity 10000
```

3. `mobile/android/gradle.properties` dosyasını düzenleyerek keystore bilgilerini ekleyin:

```
MYAPP_UPLOAD_STORE_FILE=dentiremind.keystore
MYAPP_UPLOAD_KEY_ALIAS=dentiremind
MYAPP_UPLOAD_STORE_PASSWORD=*****
MYAPP_UPLOAD_KEY_PASSWORD=*****
```

4. Release APK oluşturma:

```bash
cd mobile
npm run build:android
```

Bu komut, `mobile/android/app/build/outputs/apk/release/app-release.apk` yolunda bir APK dosyası oluşturacaktır.

#### iOS IPA Oluşturma

1. Xcode'u açın ve proje ayarlarına gidin.

2. "Signing & Capabilities" sekmesinde doğru sertifikaları ve provisioning profile'ı seçin.

3. `mobile/ios/DentiRemind/Info.plist` dosyasında versiyon ve build numaralarını güncelleyin.

4. Archive oluşturun:

```bash
cd mobile
npm run build:ios
```

Veya Xcode üzerinden:

1. Xcode > Product > Archive'ı seçin.
2. Archive tamamlandığında Organizer penceresi açılacaktır.
3. "Distribute App" düğmesine tıklayın ve adımları takip edin.

### Kesintisiz Dağıtım (CI/CD) ile Otomatikleştirme

DentiRemind, GitHub Actions kullanarak CI/CD süreçlerini otomatikleştirir:

#### Backend CI/CD Konfigürasyonu

`.github/workflows/backend-deploy.yml` dosyası:

```yaml
name: Deploy Backend

on:
  push:
    branches: [ main ]
    paths:
      - 'backend/**'
      - '.github/workflows/backend-deploy.yml'

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
      
      - name: Install Dependencies
        run: cd backend && npm ci
      
      - name: Run Tests
        run: cd backend && npm test
      
      - name: Deploy to Server
        uses: appleboy/ssh-action@master
        with:
          host: ${{ secrets.SSH_HOST }}
          username: ${{ secrets.SSH_USERNAME }}
          key: ${{ secrets.SSH_KEY }}
          script: |
            cd /var/www/dentiremind
            git pull
            cd backend
            npm ci --production
            pm2 reload dentiremind-api
```

#### Mobile App CI/CD Konfigürasyonu

`.github/workflows/mobile-deploy.yml` dosyası:

```yaml
name: Deploy Mobile App

on:
  push:
    branches: [ main ]
    paths:
      - 'mobile/**'
      - '.github/workflows/mobile-deploy.yml'

jobs:
  build-android:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
      
      - name: Install Dependencies
        run: cd mobile && npm ci
      
      - name: Setup Keystore
        run: |
          echo "${{ secrets.ANDROID_KEYSTORE }}" > mobile/android/app/dentiremind.keystore.base64
          base64 -d mobile/android/app/dentiremind.keystore.base64 > mobile/android/app/dentiremind.keystore
      
      - name: Build Android Release
        run: |
          cd mobile
          npm run build:android
      
      - name: Upload to Google Play
        uses: r0adkll/upload-google-play@v1
        with:
          serviceAccountJsonPlainText: ${{ secrets.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON }}
          packageName: com.dentiremind.app
          releaseFiles: mobile/android/app/build/outputs/bundle/release/app-release.aab
          track: production
```

## API Kullanımı

### Temel Kullanım

DentiRemind API'sini kullanarak kendi uygulamanızla entegrasyon sağlayabilirsiniz. İşte temel kullanım:

#### 1. Kimlik Doğrulama

```javascript
const axios = require('axios');

// Kullanıcı girişi
async function login(email, password) {
  try {
    const response = await axios.post('https://api.dentiremind.com/api/auth/login', {
      email,
      password
    });
    
    const { token, refreshToken } = response.data.data;
    
    // Token'ı sakla (localStorage, AsyncStorage vb.)
    saveTokens(token, refreshToken);
    
    return response.data.data.user;
  } catch (error) {
    console.error('Login error:', error.response?.data || error.message);
    throw error;
  }
}

// Token ile istek yapma
async function fetchTreatments() {
  try {
    const token = getToken(); // Saklanan token'ı al
    
    const response = await axios.get('https://api.dentiremind.com/api/treatments', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    
    return response.data.data.treatments;
  } catch (error) {
    console.error('Fetch error:', error.response?.data || error.message);
    throw error;
  }
}
```

#### 2. Tedavi Oluşturma

```javascript
async function createTreatment(treatmentData) {
  try {
    const token = getToken();
    
    const response = await axios.post('https://api.dentiremind.com/api/treatments', treatmentData, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    return response.data.data.treatment;
  } catch (error) {
    console.error('Create treatment error:', error.response?.data || error.message);
    throw error;
  }
}
```

#### 3. Hatırlatıcı Oluşturma

```javascript
async function createReminder(reminderData) {
  try {
    const token = getToken();
    
    const response = await axios.post('https://api.dentiremind.com/api/reminders', reminderData, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    return response.data.data.reminder;
  } catch (error) {
    console.error('Create reminder error:', error.response?.data || error.message);
    throw error;
  }
}
```

## SDK Kullanımı

DentiRemind, çeşitli programlama dilleri için SDK'lar sunar:

### JavaScript SDK

```javascript
// NPM ile yükleme
npm install dentiremind-sdk

// SDK'yı kullanma
const DentiRemind = require('dentiremind-sdk');

// SDK'yı başlatma
const client = new DentiRemind.Client({
  apiKey: 'YOUR_API_KEY',
  apiUrl: 'https://api.dentiremind.com'
});

// Kullanıcı girişi
async function userLogin() {
  try {
    const authResponse = await client.auth.login({
      email: 'user@example.com',
      password: 'password123'
    });
    
    // Token otomatik olarak saklanır ve sonraki isteklerde kullanılır
    console.log('Logged in as:', authResponse.user.firstName);
    
    return authResponse.user;
  } catch (error) {
    console.error('Login failed:', error.message);
  }
}

// Tedavi listesini alma
async function listTreatments() {
  try {
    const treatments = await client.treatments.list({
      status: 'active', // opsiyonel filtre
      limit: 10
    });
    
    console.log(`Found ${treatments.length} treatments`);
    return treatments;
  } catch (error) {
    console.error('Failed to fetch treatments:', error.message);
  }
}
```

### Python SDK

```python
# Pip ile yükleme
# pip install dentiremind-sdk

# SDK'yı kullanma
from dentiremind_sdk import Client

# SDK'yı başlatma
client = Client(
    api_key='YOUR_API_KEY',
    api_url='https://api.dentiremind.com'
)

# Kullanıcı girişi
def user_login():
    try:
        auth_response = client.auth.login(
            email='user@example.com',
            password='password123'
        )
        
        # Token otomatik olarak saklanır
        print(f"Logged in as: {auth_response.user.first_name}")
        
        return auth_response.user
    except Exception as e:
        print(f"Login failed: {str(e)}")

# Hatırlatıcı oluşturma
def create_reminder(treatment_id):
    try:
        reminder = client.reminders.create({
            "title": "İlaç Hatırlatıcısı",
            "description": "Antibiyotik kullanımı",
            "reminder_type": "medication",
            "date_time": "2023-06-10T08:00:00Z",
            "recurrence": {
                "pattern": "daily",
                "interval": 1,
                "end_date": "2023-06-17T08:00:00Z"
            },
            "treatment_id": treatment_id
        })
        
        print(f"Reminder created with ID: {reminder.id}")
        return reminder
    except Exception as e:
        print(f"Failed to create reminder: {str(e)}")
```

## Sorun Giderme

### Genel Sorunlar

#### 1. API Bağlantı Hatası

**Belirti**: API'ye bağlanırken "Connection refused" hatası
**Çözüm**:
- API'nin çalıştığından emin olun (`pm2 status` veya `docker ps`)
- Firewall ayarlarını kontrol edin
- Doğru API URL'sini kullandığınızdan emin olun

#### 2. Veritabanı Bağlantı Hatası

**Belirti**: "MongoDB connection error" mesajı
**Çözüm**:
- MongoDB servisinin çalıştığını kontrol edin
- Bağlantı dizesini kontrol edin
- Veritabanı kullanıcı adı ve şifresini doğrulayın

#### 3. Mobil Uygulama Build Hataları

**Belirti**: React Native build hatası
**Çözüm**:
- Node modüllerini temizleyin ve yeniden yükleyin:

```bash
rm -rf node_modules
npm install
```

- iOS için Pod'ları temizleyin ve yeniden yükleyin:

```bash
cd ios
pod deintegrate
pod install
```

- Metro bundler önbelleğini temizleyin:

```bash
npx react-native start --reset-cache
```

#### 4. JWT Hatası

**Belirti**: "Invalid signature" veya "jwt malformed" hatası
**Çözüm**:
- JWT_SECRET değerinin tüm ortamlarda aynı olduğundan emin olun
- Token'ın doğru formatla kullanıldığını kontrol edin (`Bearer` önekini doğrulayın)
- Token süresinin dolup dolmadığını kontrol edin

### Sistem Tanılama

#### API Durumunu Kontrol Etme

```bash
# PM2 ile
pm2 status dentiremind-api

# Docker ile
docker ps | grep dentiremind-api
```

#### Log Dosyalarını İnceleme

```bash
# PM2 logları
pm2 logs dentiremind-api

# Docker logları
docker logs dentiremind-api-container
```

#### Veritabanı Durumunu Kontrol Etme

```bash
# MongoDB durumu
sudo systemctl status mongodb

# MongoDB'ye bağlanma
mongo

# MongoDB içinde
> use dentiremind
> db.stats()
> db.users.count()
```

#### Sunucu Kaynaklarını Kontrol Etme

```bash
# CPU ve RAM kullanımı
htop

# Disk kullanımı
df -h
```

## Bakım ve Güncellemeler

### Düzenli Bakım Görevleri

1. **Veritabanı Yedekleme**:

```bash
# MongoDB yedekleme (günlük)
mongodump --db dentiremind --out /backup/mongodb/$(date +%Y-%m-%d)

# Otomatik yedekleme için cron job
echo "0 2 * * * mongodump --db dentiremind --out /backup/mongodb/\$(date +%Y-%m-%d)" | sudo tee -a /etc/crontab
```

2. **Log Rotasyonu**:

```bash
# PM2 log rotasyonu
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 7
```

3. **Güvenlik Güncellemeleri**:

```bash
# Sistem güncellemeleri
sudo apt update
sudo apt upgrade

# Node.js güncellemeleri
npm outdated
npm update
```

### Uygulama Güncellemeleri

#### Backend Güncelleme

```bash
# Güncellemeleri çekme
cd /var/www/dentiremind
git pull

# Bağımlılıkları güncelleme
npm ci --production

# Veritabanı migrasyonlarını çalıştırma
npm run migrate

# Uygulamayı yeniden başlatma
pm2 reload dentiremind-api
```

#### Mobile Uygulama Güncelleme

Mobil uygulama güncellemeleri, uygulama mağazaları üzerinden dağıtılır:

1. Versiyon numarasını artırın:
   - Android: `android/app/build.gradle` içinde `versionCode` ve `versionName`
   - iOS: `ios/DentiRemind/Info.plist` içinde `CFBundleShortVersionString` ve `CFBundleVersion`

2. Değişiklikleri test edin ve build alın

3. Uygulama mağazalarına dağıtın:
   - Google Play Console
   - Apple App Store Connect

## İleri Düzey Konular

### Özel Yapılandırma

`.env` dosyasında belirtilenlerin ötesinde özel yapılandırmalar için `config/custom.js` dosyası oluşturabilirsiniz:

```javascript
// config/custom.js
module.exports = {
  // Özel bildirim şablonları
  notificationTemplates: {
    // ...
  },
  
  // Sağlık izleme ayarları
  healthMonitoring: {
    // ...
  }
};
```

### Performans İyileştirmeleri

1. **Node.js Bellek Optimizasyonu**:

```bash
# Node.js bellek limitini ayarlama
NODE_OPTIONS="--max-old-space-size=4096" pm2 start ecosystem.config.js
```

2. **MongoDB İndeksleri**:

```javascript
// İndeksleri oluşturma
db.users.createIndex({ email: 1 }, { unique: true });
db.treatments.createIndex({ userId: 1, status: 1 });
db.reminders.createIndex({ nextTrigger: 1 });
```

3. **Redis Önbelleği**:

```javascript
// Redis önbellek yapılandırması
const redisConfig = {
  host: process.env.REDIS_HOST,
  port: process.env.REDIS_PORT,
  password: process.env.REDIS_PASSWORD,
  ttl: 86400, // 24 saat
  prefix: 'dentiremind:'
};
```

### Çok Bölgeli Dağıtım

Yüksek erişilebilirlik için çok bölgeli dağıtım yapılandırması:

1. Her bölgede ayrı sunucular ayarlayın
2. Bir bölge yönlendirici hizmeti kullanın (AWS Global Accelerator gibi)
3. Veritabanı replikasını her bölgede yapılandırın
4. Bölgeler arası veri senkronizasyonu için stratejiler uygulayın

Bu çok bölgeli yapılandırma, aşağıdaki faydaları sağlar:

- Düşük gecikme süresi
- Yüksek erişilebilirlik
- Felaket kurtarma koruması
- Bölgesel uyumluluk

[İçindekiler Sayfasına Dön](giris.md) 