# Veritabanı Şeması

DentiRemind uygulaması, esnek ve ölçeklenebilir bir veritabanı yapısı için MongoDB kullanmaktadır. Bu bölümde, veritabanı koleksiyonları, şemaları ve ilişkileri detaylandırılmıştır.

## Genel Veritabanı Mimarisi

DentiRemind veritabanı, aşağıdaki ana koleksiyonlardan oluşmaktadır:

1. Users (Kullanıcılar)
2. Treatments (Tedaviler)
3. Reminders (Hatırlatıcılar)
4. HealthLogs (Sağlık Günlükleri)
5. Dentists (Diş Hekimleri)
6. Appointments (Randevular)
7. TreatmentCategories (Tedavi Kategorileri)
8. Notifications (Bildirimler)

## Koleksiyon Şemaları

### Users Koleksiyonu

```javascript
{
  _id: ObjectId,
  email: String,
  passwordHash: String,
  passwordSalt: String,
  firstName: String,
  lastName: String,
  birthDate: Date,
  gender: String,
  phoneNumber: String,
  profileImage: String,
  createdAt: Date,
  updatedAt: Date,
  lastLogin: Date,
  isActive: Boolean,
  role: String, // "user", "admin", "dentist"
  settings: {
    language: String,
    notificationPreferences: {
      email: Boolean,
      push: Boolean,
      sms: Boolean
    },
    timezone: String
  },
  deviceTokens: [String], // FCM/APNS tokens
  familyMembers: [{
    _id: ObjectId,
    name: String,
    relation: String,
    birthDate: Date,
    gender: String,
    isActive: Boolean
  }]
}
```

### Treatments Koleksiyonu

```javascript
{
  _id: ObjectId,
  userId: ObjectId, // Bağlantı: Users
  familyMemberId: ObjectId, // Opsiyonel, aile üyesi için
  categoryId: ObjectId, // Bağlantı: TreatmentCategories
  title: String,
  description: String,
  startDate: Date,
  endDate: Date, // Opsiyonel, devam eden tedaviler için null
  status: String, // "scheduled", "ongoing", "completed", "cancelled"
  dentistId: ObjectId, // Bağlantı: Dentists
  location: String,
  cost: {
    amount: Number,
    currency: String
  },
  attachments: [{
    _id: ObjectId,
    filename: String,
    fileUrl: String,
    fileType: String,
    uploadDate: Date
  }],
  notes: [{
    _id: ObjectId,
    content: String,
    createdAt: Date,
    updatedAt: Date
  }],
  medication: [{
    name: String,
    dosage: String,
    frequency: String,
    startDate: Date,
    endDate: Date,
    notes: String
  }],
  createdAt: Date,
  updatedAt: Date
}
```

### Reminders Koleksiyonu

```javascript
{
  _id: ObjectId,
  userId: ObjectId, // Bağlantı: Users
  familyMemberId: ObjectId, // Opsiyonel
  treatmentId: ObjectId, // Opsiyonel, Bağlantı: Treatments
  appointmentId: ObjectId, // Opsiyonel, Bağlantı: Appointments
  title: String,
  description: String,
  reminderType: String, // "medication", "appointment", "checkup", "custom"
  dateTime: Date,
  recurrence: {
    pattern: String, // "daily", "weekly", "monthly", "yearly", "custom"
    interval: Number, // Her X günde/haftada bir
    daysOfWeek: [Number], // Haftanın günleri (0-6)
    dayOfMonth: Number, // Ayın günü
    monthOfYear: Number, // Yılın ayı
    endDate: Date, // Opsiyonel, tekrarlama sonu
    timesRepeated: Number // Opsiyonel, tekrarlama sayısı
  },
  notificationSettings: {
    beforeTime: [{
      minutes: Number, // Olay öncesi bildirim zamanı (dk)
      notificationType: String // "push", "email", "sms"
    }],
    repeatInterval: Number // Snooze için hatırlatma aralığı (dk)
  },
  isActive: Boolean,
  isMuted: Boolean,
  lastTriggered: Date,
  nextTrigger: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### HealthLogs Koleksiyonu

```javascript
{
  _id: ObjectId,
  userId: ObjectId, // Bağlantı: Users
  familyMemberId: ObjectId, // Opsiyonel
  date: Date,
  logType: String, // "checkup", "symptom", "pain", "medication", "custom"
  title: String,
  description: String,
  painLevel: Number, // 0-10 arası
  symptoms: [String],
  medications: [{
    name: String,
    dosage: String,
    taken: Boolean
  }],
  attachments: [{
    _id: ObjectId,
    filename: String,
    fileUrl: String,
    fileType: String,
    uploadDate: Date
  }],
  metadata: Object, // Çeşitli ek bilgiler
  createdAt: Date,
  updatedAt: Date
}
```

### Dentists Koleksiyonu

```javascript
{
  _id: ObjectId,
  userId: ObjectId, // Opsiyonel, eğer platform kullanıcısıysa
  firstName: String,
  lastName: String,
  specialty: String,
  clinic: {
    name: String,
    address: String,
    city: String,
    state: String,
    country: String,
    postalCode: String,
    phone: String,
    email: String,
    website: String,
    location: {
      type: "Point",
      coordinates: [Number, Number] // [longitude, latitude]
    }
  },
  workHours: [{
    day: Number, // 0-6 (Pazar-Cumartesi)
    startTime: String, // "HH:MM" formatı
    endTime: String,
    isAvailable: Boolean
  }],
  rating: Number,
  reviewCount: Number,
  isVerified: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### Appointments Koleksiyonu

```javascript
{
  _id: ObjectId,
  userId: ObjectId, // Bağlantı: Users
  familyMemberId: ObjectId, // Opsiyonel
  dentistId: ObjectId, // Bağlantı: Dentists
  treatmentId: ObjectId, // Opsiyonel, Bağlantı: Treatments
  date: Date,
  startTime: String, // "HH:MM" formatı
  endTime: String,
  status: String, // "scheduled", "confirmed", "completed", "cancelled", "missed"
  purpose: String,
  notes: String,
  reminderCreated: Boolean, // İlişkili hatırlatıcının oluşturulup oluşturulmadığı
  createdAt: Date,
  updatedAt: Date
}
```

### TreatmentCategories Koleksiyonu

```javascript
{
  _id: ObjectId,
  name: String,
  description: String,
  iconName: String,
  defaultDuration: Number, // Gün cinsinden
  isActive: Boolean,
  isMedication: Boolean, // İlaç gerektiren tedavi mi
  isCommon: Boolean, // Yaygın bir tedavi türü mü
  createdAt: Date,
  updatedAt: Date
}
```

### Notifications Koleksiyonu

```javascript
{
  _id: ObjectId,
  userId: ObjectId, // Bağlantı: Users
  title: String,
  message: String,
  notificationType: String, // "reminder", "appointment", "system"
  relatedItemId: ObjectId, // İlişkili öğe ID (tedavi, randevu vs.)
  relatedItemType: String, // İlişkili öğenin türü
  isRead: Boolean,
  createdAt: Date,
  expiresAt: Date, // Opsiyonel, bildirimin geçerlilik süresi
  actionUrl: String, // Opsiyonel, tıklandığında yönlendirilecek URL
  metadata: Object // Opsiyonel, ek bilgiler
}
```

## Veritabanı İndeksleri

Performans optimizasyonu için aşağıdaki indekslerin oluşturulması önerilmektedir:

### Users Koleksiyonu
- `email`: Unique index
- `deviceTokens`: Bildirim gönderimleri için

### Treatments Koleksiyonu
- `userId`: Kullanıcı bazlı sorgular için
- `status`: Durum bazlı sorgular için
- `startDate`, `endDate`: Tarih aralığı sorguları için

### Reminders Koleksiyonu
- `userId`: Kullanıcı bazlı sorgular için
- `nextTrigger`: Yaklaşan hatırlatıcıları sorgulamak için
- `isActive`: Aktif hatırlatıcıları sorgulamak için

### Appointments Koleksiyonu
- `userId`, `date`: Kullanıcı randevularını tarih bazlı sorgulamak için
- `dentistId`, `date`: Diş hekimi randevularını sorgulamak için
- `status`: Durum bazlı sorgular için

### Dentists Koleksiyonu
- `clinic.location`: Geo-spatial sorgular için

## Veritabanı İlişkileri

DentiRemind, MongoDB'nin referans tabanlı ilişki modelini kullanmaktadır. Aşağıdaki şema, veritabanı koleksiyonları arasındaki temel ilişkileri göstermektedir:

```
Users
  ↓ 1:N
  ├── Treatments
  │     ↓ 1:N
  │     └── Reminders
  ├── Reminders
  ├── HealthLogs
  └── Appointments
        ↓ 1:1
        └── Reminders

Dentists
  ↓ 1:N
  └── Appointments

TreatmentCategories
  ↓ 1:N
  └── Treatments
```

## Veri Tutarlılığı ve Doğrulama

Veri tutarlılığı için, uygulama katmanında Mongoose şema validasyonu kullanılmaktadır. Temel doğrulama kuralları:

- Tüm zorunlu alanlar (email, passwordHash, firstName vb.) dolu olmalıdır
- E-posta adresleri geçerli bir formatta olmalıdır
- Şifre hashlerinin uygun uzunlukta olması sağlanmalıdır
- Tarih alanları geçerli Date nesneleri olmalıdır
- Referans alanları (userId, treatmentId vb.) geçerli ObjectId nesneleri olmalıdır

## Veri Yaşam Döngüsü Yönetimi

- Silinmiş kullanıcıların verileri 30 gün boyunca saklanır, ardından tamamen silinir
- Tamamlanmış tedaviler ve randevular, kullanıcı tarafından açıkça silinmedikçe saklanır
- Geçmiş bildirimler 90 gün sonra otomatik olarak silinir
- Kullanıcı dosya ekleri, AWS S3'te saklanır ve referansları veritabanında tutulur

## Veritabanı Yedekleme Stratejisi

- Günlük tam yedekleme
- 4 saatlik artımlı yedekleme
- 30 günlük yedek saklama politikası
- Çoklu coğrafi bölgede yedekleme (Felaket kurtarma için)

[İçindekiler Sayfasına Dön](giris.md) 