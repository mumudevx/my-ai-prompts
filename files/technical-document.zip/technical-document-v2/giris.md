# DentiRemind Teknik Dokümantasyonu

## Hoş Geldiniz

Bu dokümantasyon, DentiRemind uygulamasının teknik detaylarını, mimarisini ve entegrasyon noktalarını kapsamaktadır. Bu kılavuz, geliştiriciler ve teknik ekip için hazırlanmıştır.

## İçindekiler

1. [Genel Bakış](genel-bakis.md)
2. [Sistem Mimarisi](sistem-mimarisi.md)
3. [Teknoloji Stack'i](teknoloji-stack.md)
4. [Veritabanı Şeması](veritabani-semasi.md)
5. [Backend Mimarisi](backend-mimarisi.md)
6. [API Referansı](api-referansi.md)
7. [Frontend Mimarisi](frontend-mimarisi.md)
8. [Bildirim Sistemi](bildirim-sistemi.md)
9. [Güvenlik ve KVKK Uyumluluğu](guvenlik-kvkk.md)
10. [Performans ve Ölçeklenebilirlik](performans-olceklenebilirlik.md)
11. [Entegrasyon Kılavuzu](entegrasyon-kilavuzu.md)
12. [Kurulum ve Kullanım](kurulum-kullanim.md)

## Nasıl Kullanılır

Bu dokümantasyon, modüler bir yapıda düzenlenmiştir. İlgili konuya doğrudan erişmek için yukarıdaki içindekiler bölümünden istediğiniz başlığa tıklayabilirsiniz. Her bölüm, kendi içinde alt başlıklara ayrılmıştır.

Teknik sorularınız için: teknik-destek@dentiremind.com 