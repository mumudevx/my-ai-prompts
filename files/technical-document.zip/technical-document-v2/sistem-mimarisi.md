# Sistem Mimarisi

DentiRemind uygulaması, modern yazılım mimarisi prensipleri gözetilerek, ölçeklenebilir ve sürdürülebilir bir yapıda tasarlanmıştır.

## Genel Mimari Yapı

Aşağıdaki d2 diyagramı, DentiRemind'ın temel mimari bileşenlerini ve aralarındaki ilişkileri göstermektedir:

```d2
application {
  shape: rectangle
  style: {
    fill: "#f5f5f5"
    stroke: "#000000"
  }
  
  mobile: "Mobile App" {
    shape: rectangle
    style: {
      fill: "#c6e5ff"
      stroke: "#000000"
    }
    
    ui: "User Interface"
    state: "State Management"
    auth: "Auth Module"
    data: "Data Layer"
    notify: "Notification Handler"
  }
  
  backend: "Backend Services" {
    shape: rectangle
    style: {
      fill: "#ffe6cc"
      stroke: "#000000"
    }
    
    api: "REST API"
    auth: "Auth Service"
    reminder: "Reminder Service"
    analytics: "Analytics Engine"
  }
  
  database: "Database" {
    shape: cylinder
    style: {
      fill: "#d5e8d4"
      stroke: "#000000"
    }
    
    users: "Users"
    treatments: "Treatments"
    reminders: "Reminders"
    logs: "Health Logs"
  }
  
  notification: "Notification Service" {
    shape: rectangle
    style: {
      fill: "#fff2cc"
      stroke: "#000000"
    }
  }
}

application.mobile.ui -> application.mobile.state
application.mobile.state -> application.mobile.data
application.mobile.data -> application.backend.api
application.backend.api -> application.database
application.backend.reminder -> application.notification
application.notification -> application.mobile.notify
```

## Backend Mimarisi

Backend mimarisi, aşağıdaki bileşenlerden oluşmaktadır:

### 1. API Gateway

- Tüm istemci isteklerinin giriş noktası
- İstek yönlendirme ve yük dengeleme
- Temel doğrulama ve yetkilendirme kontrolü
- Rate limiting ve throttling

### 2. Mikroservisler

#### a. Kullanıcı Servisi
- Kullanıcı kaydı ve kimlik doğrulama
- Profil yönetimi
- Oturum işlemleri

#### b. Tedavi Servisi
- Tedavi kayıtları oluşturma ve yönetme
- Tedavi kronolojisi
- Tedavi kategorileri ve metadata yönetimi

#### c. Hatırlatıcı Servisi
- Hatırlatıcı oluşturma ve zamanlama
- Tekrarlayan hatırlatıcı mantığı
- Bildirim tetikleyici

#### d. Analitik Servisi
- Kullanıcı davranışı izleme
- Tedavi istatistikleri hesaplama
- Raporlama ve dashboard veri işleme

### 3. Veritabanı Katmanı

- Ana MongoDB veritabanı (kullanıcı verileri ve tedavi kayıtları)
- Redis önbellek (sık erişilen veriler ve oturum bilgileri)
- Elasticsearch (arama ve analitik)

### 4. Harici Servisler

- Bildirim Servisi (Firebase Cloud Messaging)
- E-posta Servisi (SendGrid)
- Dosya Depolama (AWS S3)

## Frontend Mimarisi

Mobile uygulama, aşağıdaki katmanlardan oluşmaktadır:

### 1. Sunum Katmanı
- Kullanıcı arayüzü bileşenleri
- Ekran yapıları
- Navigasyon

### 2. Durum Yönetimi
- Global uygulama durumu
- Bileşen durumları
- Önbellek yönetimi

### 3. İş Mantığı Katmanı
- Veri transformasyonu
- İş kuralları uygulaması
- Form validasyonu

### 4. Veri Erişim Katmanı
- API istemcisi
- Yerel depolama
- Senkronizasyon mantığı

## Veri Akışı

1. Kullanıcı, uygulamanın arayüzü aracılığıyla bir eylem gerçekleştirir (ör. yeni bir tedavi kaydı oluşturma)
2. İstek, mobil uygulamanın veri katmanına iletilir
3. Veri katmanı, isteği API Gateway'e gönderir
4. API Gateway, isteği ilgili mikroservise yönlendirir
5. Mikroservis, isteği işler ve veritabanına gerekli yazma/okuma işlemlerini gerçekleştirir
6. Sonuç, aynı yol üzerinden geriye döner ve kullanıcıya gösterilir
7. Gerekli durumlarda (ör. hatırlatıcı zamanı geldiğinde), bildirim servisi tetiklenir ve kullanıcıya push bildirimi gönderilir

## Çevrimdışı Çalışma

DentiRemind, çevrimdışı çalışabilme özelliğine sahiptir:

1. Yerel veritabanında veri saklama (SQLite)
2. Çevrimdışı işlemleri kuyruklama
3. Bağlantı sağlandığında otomatik senkronizasyon
4. Çakışma çözümleme stratejileri

## Ölçeklenebilirlik

Mimari, yatay ve dikey ölçeklenebilirlik sağlayacak şekilde tasarlanmıştır:

- Mikroservisler bağımsız olarak ölçeklendirilebilir
- Veritabanı sharding ve replikasyon desteği
- Önbellek stratejileri ile yük azaltma
- Container orchestration (Kubernetes) ile dinamik ölçeklendirme

[İçindekiler Sayfasına Dön](giris.md) 